const fs=require('fs'),vm=require('vm'),path=require('path');
const root='D:/嘉立创/lceda-pro/resources/app/assets/pro-mgr';
const file=path.join(root,fs.readdirSync(root)[0],'js/project-worker.js');
let source=fs.readFileSync(file,'utf8');
const end=source.lastIndexOf('console.log("[OPEN PROJECT] Init worker")');
source=source.slice(0,end)+';globalThis.__parser={Project:el,Symbol:Pi};})();';
const sandbox={console,TextEncoder,TextDecoder,URL,Blob,atob,btoa,Uint8Array,Uint16Array,Uint32Array,ArrayBuffer,
    TransformStream,ReadableStream,WritableStream,performance,
    setTimeout:()=>0,clearTimeout:()=>{},setInterval:()=>0,clearInterval:()=>{},
    navigator:{userAgent:'Mozilla/5.0',language:'zh-CN'},location:{href:'http://localhost/'},
    addEventListener(){},postMessage(){},importScripts(){},crypto:require('crypto').webcrypto};
sandbox.self=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
try{vm.runInContext(source,sandbox,{timeout:15000});console.log('Loaded actual EDA worker',Object.keys(sandbox.__parser));}
catch(e){console.log(e.name,e.message,e.stack.split('\n').slice(-9).join('\n'));process.exit(1)}
if(process.argv[2]){
    const raw=fs.readFileSync(process.argv[2],'utf8');
    const p=new sandbox.__parser.Project();
    try{
        const data=p.start(raw);
        const stats=Object.fromEntries(Object.entries(data).filter(([k,v])=>typeof v==='object').map(([k,v])=>[k,Object.keys(v).length]));
        console.log('Parsed',stats);
        const lib=Object.values(data.symbols)[0];console.log('First symbol',Object.keys(lib),lib.docType);
        fs.writeFileSync(process.argv[2]+'.actual.json',JSON.stringify(data));
    }catch(e){console.log(e.stack);process.exitCode=1}
}
