const fs=require('fs'),vm=require('vm'),path=require('path');
const root='D:/嘉立创/lceda-pro/resources/app/assets/pro-mgr';
const file=path.join(root,fs.readdirSync(root)[0],'js/project-worker.js');
let source=fs.readFileSync(file,'utf8');
const end=source.lastIndexOf('console.log("[OPEN PROJECT] Init worker")');
source=source.slice(0,end)+';globalThis.__parser={Project:el,Symbol:Pi,Canvas:Uc};})();';
const sandbox={console,TextEncoder,TextDecoder,URL,Blob,atob,btoa,Uint8Array,Uint16Array,Uint32Array,ArrayBuffer,
    TransformStream,ReadableStream,WritableStream,performance,
    setTimeout:()=>0,clearTimeout:()=>{},setInterval:()=>0,clearInterval:()=>{},
    navigator:{userAgent:'Mozilla/5.0',language:'zh-CN'},location:{href:'http://localhost/'},
    addEventListener(){},postMessage(){},importScripts(){},crypto:require('crypto').webcrypto};
sandbox.self=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
try{vm.runInContext(source,sandbox,{timeout:15000});console.log('Loaded actual EDA worker',Object.keys(sandbox.__parser));}
catch(e){console.log(e.name,e.message,e.stack.split('\n').slice(-9).join('\n'));process.exit(1)}

const assert=require('assert');
const raw=fs.readFileSync(process.argv[2],'utf8');
const data=new sandbox.__parser.Project().start(raw);
const symbols=Object.values(data.symbols),sheets=Object.values(data.sheets);
assert.strictEqual(symbols.length,139);assert.strictEqual(sheets.length,1);
const sheet=sheets[0];assert.strictEqual(data.config.defaultSheet,sheet.uuid);
let graphics=0,pins=0;
for(const s of symbols){
 assert.strictEqual(s.docType,2);
 assert(s.creator.uuid);
 const lines=s.canvas.trim().split('\n').map(l=>{const i=l.indexOf('||');let b=l.slice(i+2);if(b.endsWith('|'))b=b.slice(0,-1);return [JSON.parse(l.slice(0,i)),JSON.parse(b)]});
 const parts=new Set(lines.filter(l=>l[0].type==='PART').map(l=>l[0].id));
 const gs=lines.filter(l=>['RECT','POLY','ELLIPSE','ARC'].includes(l[0].type));
 assert(gs.length>0,s.title);graphics+=gs.length;
 for(const [h,b] of lines){if(h.type==='PIN'){assert(parts.has(b.partId));pins++}}
 const c=new sandbox.__parser.Canvas();let events=0;
 c.onChange(()=>events++);c.parseFull(s.canvas);assert(events>0,s.title);
}
const refs=sandbox.__parser.Symbol.sheet(sheet.canvas).dataSet;
assert.strictEqual(refs.symbols.size,139);assert.strictEqual(refs.devices.size,139);
for(const id of refs.symbols) assert(data.symbols[id]);
for(const id of refs.devices){const dev=data.devices[id];assert(dev);assert(data.symbols[dev.attributes.Symbol]);assert(data.footprints[dev.attributes.Footprint]);}
assert.strictEqual(pins,427);
const result={official_client_version:'3.2.91',sheets:1,symbols:symbols.length,devices:refs.devices.size,pins,graphics,all_symbol_docType:2,defaultSheet_valid:true,all_library_references_valid:true,canvas_parser_pass:true,limits:'Parser validation only; editor display and ERC/DRC not tested.'};
fs.writeFileSync('tmp/import-repair/official-check.json',JSON.stringify(result,null,2));
console.log(result);
