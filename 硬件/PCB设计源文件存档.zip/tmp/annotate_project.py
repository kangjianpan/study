"""Add assembly notes only; preserve every schematic/PCB electrical record."""
from pathlib import Path
import copy
import hashlib
import json
import uuid
import zipfile

root = Path.cwd()
project = root/'硬件/童骑卫-底板v2-PCB样机版.epro2'
with zipfile.ZipFile(project) as z:
    files = {n: z.read(n) for n in z.namelist()}
name = next(n for n in files if n.endswith('.epru'))
docs = []
for line in files[name].decode('utf-8').splitlines():
    h, b = line.split('||', 1)
    h, b = json.loads(h), json.loads(b[:-1])
    if h['type'] == 'DOCHEAD': docs.append([])
    docs[-1].append((h, b))
pcb = next(d for d in docs if d[0][1]['docType'] == 'PCB')
original_pcb = copy.deepcopy(pcb)
sheet = next(d for d in docs if d[0][1]['docType'] == 'SCH_PAGE')
for h,b in sheet:
    if h['type'] == 'TEXT' and b['y'] == -10:
        b['value'] = '同名网络相连；PCB已布局布线及底层GND铺铜。投板前须完成ERC/DRC与实物尺寸核对。'
template = copy.deepcopy(next(b for h,b in sheet if h['type'] == 'TEXT'))
notes = [
    '急停必接：J18-1(+5V) → 外部急停NC动力触点 → J18-2(COIL_PLUS) → 5V线圈正。线圈负 → J18-3。',
    '禁止在PCB上短接COIL_PLUS与+5V；漏接会导致继电器不吸合。主动力电流不经过底板。',
    'Q4/Q5随CORE_3V3自动开关传感器5V，防止核心板断电回灌；不是预留GPIO控制开关。',
    '安全带/轮速只接5V供电、开集电极输出器件，信号上拉3.3V；不得直接接5V推挽输出。',
    'PC13为ARM回读输入，不能作LED输出；当前固件默认禁止行驶，实物验收后才开放。',
]
for i,note in enumerate(notes):
    if any(h['type']=='TEXT' and b.get('value')==note for h,b in sheet):continue
    b = copy.deepcopy(template)
    b.update(x=3300, y=1460+i*20, fontSize=11, value=note)
    sheet.append(({'type':'TEXT','id':uuid.uuid4().hex[:16]},b))
for i,(h,b) in enumerate(sheet,1): h['ticket']=i
assert pcb == original_pcb
raw = '\n'.join(json.dumps(h,ensure_ascii=False,separators=(',',':'))+'||'+
    json.dumps(b,ensure_ascii=False,separators=(',',':'))+'|' for d in docs for h,b in d)+'\n'
files[name] = raw.encode('utf-8')
with zipfile.ZipFile(project, 'w', zipfile.ZIP_DEFLATED) as z:
    for name,data in files.items(): z.writestr(name,data)
with zipfile.ZipFile(project) as z: assert z.testzip() is None
(root/'tmp/pcb-v2/final.epru').write_bytes(raw.encode('utf-8'))
print('Schematic assembly notes added; all PCB records unchanged.')
print(hashlib.sha256(project.read_bytes()).hexdigest())
