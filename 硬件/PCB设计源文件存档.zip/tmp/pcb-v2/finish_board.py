"""Finish copper plane, silkscreen and native EasyEDA project packaging."""
import copy
import hashlib
import time
import uuid
import zipfile
from geometry import *
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from import_ses import connectivity

NOW=int(time.time()*1000)
def uid():return uuid.uuid4().hex[:16]
def meta(d):return next(r['b'] for r in d['records'] if r['h']['type']=='META')
def add(d,t,b,i=None):
    d['records'].append({'h':{'type':t,'id':i or uid()},'b':b})
def mil(v):return round(v/.0254,5)

routed=json.loads((BASE/'routed.json').read_text(encoding='utf-8'))
routes=routed['routes'];vias=routed['vias']
for r in routes:
    if r['net']=='+5V' and r['width']==.2:r['width']=.28
    if r['net']=='VBUS_USB' and r['width']==.2:r['width']=.25
objs=items(routes,vias)
assert not check(objs)
assert not component_pad_check(objs)
assert not connectivity(objs)
assert body_check()==([],[])

# Actual bottom copper, with thermal relief at plated through-hole GND pads.
cutters=[]
for o in objs:
    if 2 in o['layers'] and o['net']!='GND':
        cutters.append(o['shape'].buffer(.55 if o['net'] in HV else .24,quad_segs=8))
for x,y in HOLES:cutters.append(Point(x,y).buffer(3.2,quad_segs=24))
cutters.append(box(27,77.3,34.6,85.5))
plane=box(.5,.5,WIDTH-.5,HEIGHT-.5).difference(unary_union(cutters))
for o in objs:
    if o['type']!='pad' or o['net']!='GND' or not o['pad']['hole']:continue
    p=o['pad'];x,y=p['x'],p['y'];reach=max(p['w'],p['h'])/2+.7
    spokes=unary_union([box(x-reach,y-.2,x+reach,y+.2),box(x-.2,y-reach,x+.2,y+reach)])
    plane=plane.difference(o['shape'].buffer(.35).difference(spokes))
plane=plane.buffer(-.12,quad_segs=4).buffer(.12,quad_segs=4).simplify(.005,preserve_topology=True)
gnd=unary_union([o['shape'] for o in objs if o['net']=='GND' and 2 in o['layers']])
polys=list(plane.geoms) if hasattr(plane,'geoms') else [plane]
polys=[orient(p,1) for p in polys if p.area>1 and p.intersects(gnd)]
plane=unary_union(polys)
assert plane.is_valid
planeitem=dict(name='GND_plane',net='GND',layers=[2],type='plane',shape=plane)
assert not check(objs+[planeitem])
assert not connectivity(objs+[planeitem])
(BASE/'ground-plane.wkt').write_text(plane.wkt,encoding='ascii')

def path(poly):
    poly=orient(poly,1)
    loops=[]
    for ring in [poly.exterior,*poly.interiors]:
        coords=list(ring.coords)
        loops.append([mil(coords[0][0]),mil(coords[0][1]),'L',*
                      [mil(v) for xy in coords[1:] for v in xy]])
    return loops

pcb=next(d for d in DOCS if d['head']['docType']=='PCB')
meta(pcb)['title']='PCB_130x100_已布局布线_待编辑器DRC'
pcb['head'].update(updateTime=NOW,version=str(NOW))
at={}
for r in pcb['records']:
    if r['h']['type']=='ATTR':at.setdefault(r['b'].get('parentId',''),{})[r['b']['key']]=r

# Clear unusual old paste shrink overrides; preserve all pad sizes/numbers.
for fp in (d for d in DOCS if d['head']['docType']=='FOOTPRINT'):
    for r in fp['records']:
        if r['h']['type']=='PAD' and r['b']['layerId']==1:
            if (r['b'].get('topPasteExpansion') or 0)<-10:r['b']['topPasteExpansion']=None
            if (r['b'].get('bottomPasteExpansion') or 0)<-10:r['b']['bottomPasteExpansion']=None

# Make readable silkscreen from body boundaries, clipped away from own pads.
for fp in (d for d in DOCS if d['head']['docType']=='FOOTPRINT'):
    ref=next(r for r,p in PART.items() if p['footprint_id']==fp['head']['uuid'])
    x,y,angle=PLACE[ref]
    body=body_shape(ref)
    body=rotate(translate(body,-x,-y),-angle,origin=(0,0))
    keep=unary_union([pad_shape(p).buffer(.22) for p in pads(ref,False)])
    boundary=body.boundary.difference(keep)
    fp['records']=[r for r in fp['records'] if not(r['b'].get('layerId')==3 and
                         r['h']['type'] in ['POLY','FILL','LINE','ARC','STRING'])]
    pieces=list(boundary.geoms) if hasattr(boundary,'geoms') else [boundary]
    for piece in pieces:
        if piece.length<.3:continue
        xy=list(piece.coords)
        add(fp,'POLY',{'groupId':0,'netName':'','layerId':3,'width':mil(.12),
            'path':[mil(xy[0][0]),mil(xy[0][1]),'L',*[mil(v) for pt in xy[1:] for v in pt]],
            'locked':False,'zIndex':1,'polyType':'NORMAL'})

def string(text,x,y,size=.9,layer=3,angle=0):
    b={'partitionId':'','groupId':0,'layerId':layer,'x':mil(x),'y':mil(y),'text':text,
       'fontFamily':'default','fontSize':mil(size),'strokeWidth':mil(.12),'bold':False,
       'italic':False,'origin':'CENTER_MIDDLE','angle':angle,'reverse':False,
       'expansion':0,'mirror':layer==4,'locked':False,'zIndex':1}
    add(pcb,'STRING',b)
    return b

occupied=[o['shape'].buffer(.25) for o in objs if o['type']=='pad']
occupied += [body_shape(ref).buffer(.13) for ref in PART]
occupied += [Point(x,y).buffer(3.3) for x,y in HOLES]
occupied += [box(40.33,47.57,93.67,70.43)]
labels={}
board_inner=box(.6,.6,WIDTH-.6,HEIGHT-.6)

def reserve_text(value,x,y,size):
    w=len(value)*size*.66+.25;h=size*1.35+.15
    rect=box(x-w/2,y-h/2,x+w/2,y+h/2)
    if not board_inner.covers(rect):return None
    if any(rect.intersects(other) for other in occupied):return None
    occupied.append(rect)
    return rect

# Large legends in the free centre, plus explicit supply warnings.
for text,x,y,size in [
    ('GUARDKART CARRIER v2',67,43.3,1.8),
    ('7S Li-ion 29.4V MAX',67,40,1.1),
    ('MOTOR POWER OFF-BOARD',67,37.7,1.0),
    ('130x100mm / 2L / 1.6mm / 1oz',67,34.8,.9),
    ('CORE USB: POWER OFF, REMOVE JP1',67,32.5,.85),
]:
    assert reserve_text(text,x,y,size),text
    string(text,x,y,size)

legends=[
    ('BAT 7S',14,88.5,.8),('ESP32',43,98,.85),('IMU',62,98,.85),('NFC',83.5,98,.85),('ToF-L',107,98,.85),
    ('COIL 5V',121,90,.8),('E-STOP NC',122,77.7,.75),('ToF-R',120.3,66.8,.8),
    ('ARM NO',124,49.4,.8),('ESC PWM',124,39,.8),('BUZZ',124,26.8,.8),
    ('SEAT-R',109,1.3,.85),('SEAT-L',92,1.3,.85),('PEDAL 5V',75,1.3,.85),
    ('CURRENT',60,1.3,.85),('HALL-L',46,1.3,.85),('HALL-R',30,1.3,.85),('BELT',6,42.3,.85),
    ('USB',14.5,10.8,.85),
]
placed_legends=[]
for txt,x,y,size in legends:
    found=False
    offsets=[(0,0),(0,1),(0,-1),(-2,0),(2,0),(0,2),(0,-2),(-4,0),(4,0),(0,3),(0,-3),(-6,0),(6,0)]
    for dx,dy in offsets:
        if reserve_text(txt,x+dx,y+dy,size):
            placed_legends.append((txt,x+dx,y+dy,size));found=True;break
    assert found,('No legend position',txt)

# Designators are placed outside solderable copper and component bodies.
for ref in sorted(PART,key=lambda r:(not r.startswith('J'),-body_shape(r).area,r)):
    b=body_shape(ref);x1,y1,x2,y2=b.bounds;cx=(x1+x2)/2;cy=(y1+y2)/2
    positions=[]
    for gap in [.8,1.4,2.2,3.1,4.2,5.4,7.0]:
        positions += [(cx,y2+gap),(cx,y1-gap),(x2+gap+len(ref)*.3,cy),(x1-gap-len(ref)*.3,cy)]
        for dx in [-2,2,-4,4]:positions.extend([(cx+dx,y2+gap),(cx+dx,y1-gap)])
    found=None
    for size in [.85,.75]:
        for x,y in positions:
            if reserve_text(ref,x,y,size):found=(x,y,size);break
        if found:break
    assert found,('No safe designator position',ref)
    x,y,size=found;labels[ref]={'x':x,'y':y,'size':size}
    # Actual reference attributes, rather than duplicate free text.
    b=at[PART[ref]['cid']]['Designator']['b']
    b.update(x=mil(x),y=mil(y),fontSize=mil(size),strokeWidth=mil(.12),origin='CENTER_MIDDLE',angle=0,valueVisible=True)

for txt,x,y,size in placed_legends:string(txt,x,y,size)

for ref,p in PART.items():
    if not ref.startswith('J'):continue
    # Visible pin-1 marker next to each connector, using pad geometry.
    p1=pin(ref,'B1A12' if ref=='J15' else 1)
    if ref=='J15':continue
    for dx,dy in [(0,2.2),(0,-2.2),(-2.2,0),(2.2,0),(0,3),(-3,0),(3,0)]:
        if reserve_text('1',p1['x']+dx,p1['y']+dy,.7):
            string('1',p1['x']+dx,p1['y']+dy,.7);break

for r in pcb['records']:
    if r['h']['type']=='COMPONENT':
        cid=r['h']['id'];ref=at[cid]['Designator']['b']['value'];x,y,angle=PLACE[ref]
        r['b'].update(x=mil(x),y=mil(y),angle=angle,locked=False)
    elif r['h']['type']=='ATTR' and r['b']['key']!='Designator':
        r['b']['valueVisible']=False
    elif r['h']['type']=='CANVAS':
        r['b'].update(unit='mm',originX=0,originY=0,gridXSize=mil(.5),gridYSize=mil(.5),snapXSize=mil(.25),snapYSize=mil(.25))

add(pcb,'POLY',{'partitionId':'','groupId':0,'netName':'','layerId':11,'width':mil(.1),
    'path':[0,0,'L',mil(WIDTH),0,mil(WIDTH),mil(HEIGHT),0,mil(HEIGHT),0,0],
    'locked':True,'zIndex':1,'polyType':'BOARD_OUTLINE'})
add(pcb,'POLY',{'partitionId':'','groupId':0,'netName':'','layerId':9,'width':mil(.15),
    'path':[mil(40.33),mil(47.57),'L',mil(93.67),mil(47.57),mil(93.67),mil(70.43),
        mil(40.33),mil(70.43),mil(40.33),mil(47.57)],
    'locked':True,'zIndex':1,'polyType':'NORMAL'})
string('TLS STM32F103C8 / 53.34x22.86',67,59,1.2,layer=9)
for x,y in HOLES:
    b=copy.deepcopy(next(r['b'] for r in IDX[PART['C1']['footprint_id']]['records'] if r['h']['type']=='PAD'))
    b.update(partitionId='',groupId=0,netName='',layerId=12,num='',centerX=mil(x),centerY=mil(y),
             padAngle=0,hole={'holeType':'ROUND','width':mil(3.2),'height':mil(3.2)},
             defaultPad={'padType':'ELLIPSE','width':mil(3.2),'height':mil(3.2)},
             padOffsetX=0,padOffsetY=0,relativeAngle=0,plated=False,padType='NORMAL',
             topSolderExpansion=0,bottomSolderExpansion=0,topPasteExpansion=-1000,bottomPasteExpansion=-1000,
             locked=True)
    add(pcb,'PAD',b)
for r in routes:
    for a,b in zip(r['points'],r['points'][1:]):
        if a==b:continue
        add(pcb,'LINE',{'partitionId':'','groupId':0,'netName':r['net'],'layerId':r['layer'],
            'startX':mil(a[0]),'startY':mil(a[1]),'endX':mil(b[0]),'endY':mil(b[1]),
            'width':mil(r['width']),'locked':False,'zIndex':1})
for v in vias:
    add(pcb,'VIA',{'partitionId':'','groupId':0,'netName':v['net'],'ruleName':'',
        'centerX':mil(v['x']),'centerY':mil(v['y']),'holeDiameter':mil(v['hole']),
        'viaDiameter':mil(v['diameter']),'viaType':'NORMAL','topSolderExpansion':None,
        'bottomSolderExpansion':None,'locked':False,'zIndex':1,'unusedInnerLayers':None})
pid=uid()
add(pcb,'POUR',{'partitionId':'','groupId':0,'netName':'GND','layerId':2,'width':mil(.25),
    'name':'GND_bottom','order':1,'path':[mil(.5),mil(.5),'L',mil(WIDTH-.5),mil(.5),
        mil(WIDTH-.5),mil(HEIGHT-.5),mil(.5),mil(HEIGHT-.5),mil(.5),mil(.5)],
    'pourType':{'pourType':'SOLID','fineness':mil(.25)},'keepIsland':False,'locked':False,'zIndex':1},pid)
add(pcb,'POURED',{'pourFill':[{'id':uid(),'strokeWidth':0,'fill':True,'path':path(p)} for p in polys]},
    json.dumps(['POURED',pid],separators=(',',':')))

# Refill copper with the same deliberate thermal settings in the editor.
for r in pcb['records']:
    if r['h']['type']=='RULE':
        key=json.loads(r['h']['id'])
        if key[1]=='COPPER':
            for k in ['sglPad','mulPad']:
                for t in r['b']['ruleContext'][k]['content']:
                    t.update(spoSpac=mil(.35),spoWidth=mil(.4))

for d in DOCS:
    if d['head']['docType']=='FOOTPRINT':d['head'].update(updateTime=NOW,version=str(NOW))
    d['records'][0]['b']=d['head']
    for i,r in enumerate(d['records'],1):
        r['h']['ticket']=i;r['h'].pop('firstTicket',None)
raw='\n'.join(json.dumps(r['h'],ensure_ascii=False,separators=(',',':'))+'||'+
              json.dumps(r['b'],ensure_ascii=False,separators=(',',':'))+'|'
              for d in DOCS for r in d['records'])+'\n'
(BASE/'final.epru').write_bytes(raw.encode('utf-8'))
output=ROOT/'硬件/童骑卫-底板v2-PCB样机版.epro2'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('project2.json',json.dumps({'title':'童骑卫-底板v2-PCB样机版','cbb_project':False,
        'editorVersion':'3.2.91','tags':'[]','description':'130x100mm 双层；原理图、布局、布线、接地铺铜；待在线显示、官方ERC/DRC、工艺与实物适配核验。'},ensure_ascii=False))
    z.writestr('童骑卫-底板v2-PCB样机版.epru',raw)
with zipfile.ZipFile(output) as z:assert z.testzip() is None
(BASE/'final-design.json').write_text(json.dumps({'routes':routes,'vias':vias,'labels':labels},indent=2),encoding='utf-8')
(BASE/'pcb-project.json').write_text(json.dumps(DOCS,ensure_ascii=False),encoding='utf-8')
print(output)
print('SHA256',hashlib.sha256(output.read_bytes()).hexdigest())
print('Plane area',plane.area,'regions',len(polys),'tracks',sum(len(r['points'])-1 for r in routes),'vias',len(vias))
