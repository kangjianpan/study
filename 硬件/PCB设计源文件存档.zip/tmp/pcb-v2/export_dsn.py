"""Emit a two-layer Specctra design with fixed switching/USB routes."""
import collections
import json
import math
from board import *

ROUTES=[]
VIAS=[]

def route(net,points,width=.25,layer=1):
    ROUTES.append(dict(net=net,points=points,width=width,layer=layer))

def via(net,x,y,diameter=.6,hole=.3):
    VIAS.append(dict(net=net,x=x,y=y,diameter=diameter,hole=hole))

def connect(ref1,n1,ref2,n2,width=.25,middle=(),layer=1):
    a=pin(ref1,n1);b=pin(ref2,n2)
    assert a['net']==b['net'] and a['net'],(ref1,n1,ref2,n2)
    route(a['net'],[(a['x'],a['y']),*middle,(b['x'],b['y'])],width,layer)

# Input and power switch: the autorouter cannot modify these local loops.
connect('J1',1,'F1',1,1.0,[(11.46,90),(11.5,86)])
connect('F1',2,'D11',2,1.0)
connect('F1',2,'D1',1,.8,[(16.5,83.5),(6.5,83.5),(6.5,76.9)])
connect('D11',1,'C1',1,1.0,[(29.5,86),(31.5,88)])
a=pin('C1',1)
route('VBAT',[(a['x'],a['y']),(27,89),(27,81),(12.8,81),(12.8,76.635)],1.0,2)
via('VBAT',12.8,76.635)
a=pin('C23',1);route('VBAT',[(12.8,76.635),(a['x'],a['y'])],1.0)
connect('C23',1,'C4',1,1.0)
connect('C4',1,'U1',2,.8)
connect('C4',2,'U1',1,.6,[(21,79.635),(22.3,78.335)])
connect('C23',2,'C4',2,.8)
connect('C2',1,'U1',2,.5,[(17.5,73),(17.5,76.635)])
connect('U1',8,'L1',1,1.0,[(29.8,80.005)])
connect('L1',2,'C5',1,1.0)
connect('C5',1,'C6',1,.8,[(38.5,78.8)])
connect('U1',7,'C3',1,.25)
connect('C3',2,'U1',8,.35,[(30.5,77.905)])
connect('U1',6,'C24',1,.25,[(28.8,75.365),(29.1,75.065)])
connect('U1',5,'R3',1,.2,[(28.25,74.095),(28.25,68.947)])
connect('R3',1,'R2',2,.2,[(31.7,68.947),(33.253,70.5)])

# Four open thermal vias in the exposed GND pad, kept away from its paste edge.
for x in [24.45,25.55]:
    for y in [75.3,76.7]:via('GND',x,y,.55,.3)
connect('U1',1,'U1',9,.6,[(24.2,77.905),(25,77.1)])

# Power OR: explicit fine-pitch escape before the wider 5 V distribution.
connect('U3',2,'U3',7,.2)
connect('U3',7,'C25',1,.2,[(47.6,79.25)])
a=pin('U3',3);route(a['net'],[(a['x'],a['y']),(43.2,78.75)],.2)
via('+5V_BUCK',43.2,78.75)
via('+5V_BUCK',38.8,84.7)
route('+5V_BUCK',[(38.8,84.7),(43.2,84.7),(43.2,78.75)],.8,2)
a=pin('C5',1);route(a['net'],[(a['x'],a['y']),(38.8,81.9),(38.8,84.7)],.8)
for num,points in [
    (1,[(44.3,80.21),(44.3,80.4)]),(4,[(44.1,78.25),(43.3,77.45)]),
    (5,[(46.24,76.7)]),
]:
    a=pin('U3',num);xy=[(a['x'],a['y']),*points]
    route('GND',xy,.2);via('GND',*points[-1])
a=pin('U3',6)
route('VBUS_USB',[(a['x'],a['y']),(46.9,78.75),(47.2,78.45),(47.2,77.9)],.2)
via('VBUS_USB',47.2,77.9)

# USB-C duplicated data contacts. D+ crosses on bottom, D- stays on top.
for num,x in [('A6',14.2),('B6',15.7)]:
    a=pin('J15',num)
    route('USB_DP',[(a['x'],a['y']),(a['x'],6.75),(x,7.2),(x,7.35)],.2)
    via('USB_DP',x,7.35)
route('USB_DP',[(14.2,7.35),(15.7,7.35),(20.2,11.85),(20.2,18.635)],.2,2)
via('USB_DP',20.2,18.635)
a=pin('U2',5);route('USB_DP',[(20.2,18.635),(a['x'],a['y'])],.2)
a=pin('J15','A7');route('USB_DN',[(a['x'],a['y']),(14.75,7.0),(14.9,7.15),(14.9,8.5)],.2)
a=pin('J15','B7');route('USB_DN',[(a['x'],a['y']),(13.75,6.75),(13.1,7.4),(13.1,8.5),(14.9,8.5)],.2)
a=pin('U2',6)
route('USB_DN',[(14.9,8.5),(20.9,14.5),(20.9,a['y']),(a['x'],a['y'])],.2)

def um(v):return str(round(v*1000))
def q(v):return json.dumps(str(v),ensure_ascii=True)
out=['(pcb GuardKart_v2',' (parser (string_quote ") (space_in_quoted_tokens on) (host_cad "Carrier physical design") (host_version "2"))',
     ' (resolution um 1)',' (unit um)',' (structure',
     '  (layer F.Cu (type signal) (property (index 0)))',
     '  (layer B.Cu (type signal) (property (index 1)))',
     f'  (boundary (rect pcb 0 0 {um(WIDTH)} {um(HEIGHT)}))',
     '  (via V600_300 V550_300)',
     '  (rule (width 250) (clearance 180) (clearance 180 (type default_smd)))']
# Unconnected round pads reserve washer areas. The native router build has a
# serialization defect for ObstacleArea keepouts, so represent these as pins.
out+=['  (control (via_at_smd on))',
      '  (autoroute_settings (fanout on) (autoroute on) (postroute on) (vias on) (via_costs 35)',
      '    (layer_rule F.Cu (active on) (preferred_direction horizontal) (preferred_direction_trace_costs 1) (against_preferred_direction_trace_costs 1.2))',
      '    (layer_rule B.Cu (active on) (preferred_direction vertical) (preferred_direction_trace_costs 1) (against_preferred_direction_trace_costs 1.2)))',
      ' )',' (placement']
for ref,(x,y,ang) in PLACE.items():
    out.append(f'  (component {q(ref)} (place {ref} {um(x)} {um(y)} front {ang}))')
for i,(x,y) in enumerate(HOLES):
    out.append(f'  (component MOUNT_KEEP (place H{i+1} {um(x)} {um(y)} front 0))')
out.append('  (component THERMAL (place T1 25000 76000 front 0))')
out+=[' )',' (library']
padstacks=[]
netpins=collections.defaultdict(list)
for ref in PLACE:
    out.append(f'  (image {q(ref)}')
    for p in pads(ref,False):
        name=ref+'_'+p['dsn_pin']
        out.append(f'   (pin {name} {p["dsn_pin"]} {um(p["x"])} {um(p["y"])} )')
        layers=['F.Cu','B.Cu'] if p['hole'] else ['F.Cu']
        text=[f'  (padstack {name}']
        for layer in layers:
            if p['shape']=='ELLIPSE' and abs(p['w']-p['h'])<.01:
                shape=f'(circle {layer} {um(p["w"])})'
            else:
                pts=[rot(x,y,p['angle']) for x,y in [(-p['w']/2,-p['h']/2),(p['w']/2,-p['h']/2),(p['w']/2,p['h']/2),(-p['w']/2,p['h']/2)]]
                shape=f'(polygon {layer} 0 '+ ' '.join(um(v) for xy in pts for v in xy)+')'
            text.append('   (shape '+shape+')')
        text.append('   (attach off))');padstacks.extend(text)
        if p['net']:netpins[p['net']].append(ref+'-'+p['dsn_pin'])
    out.append('  )')
out+=padstacks
out.append('  (image MOUNT_KEEP (pin MOUNT_PAD 1 0 0))')
out.append('  (padstack MOUNT_PAD (shape (circle F.Cu 6000)) (shape (circle B.Cu 6000)) (attach off))')
out.append('  (image THERMAL (pin THERMAL_PAD 1 -550 -700) (pin THERMAL_PAD 2 -550 700) (pin THERMAL_PAD 3 550 -700) (pin THERMAL_PAD 4 550 700))')
out.append('  (padstack THERMAL_PAD (shape (circle F.Cu 550)) (shape (circle B.Cu 550)) (attach off))')
netpins['GND'] += ['T1-1','T1-2','T1-3','T1-4']
for name,d in [('V600_300',600),('V550_300',550)]:
    out.append(f'  (padstack {name} (shape (circle F.Cu {d})) (shape (circle B.Cu {d})) (attach off))')
out+=[' )',' (network']
for net,pins in netpins.items():out.append(f'  (net {q(net)} (pins '+ ' '.join(pins)+'))')
classes={
 'HighVoltage':(['VIN_IN','VIN_F','VBAT'],800,500),
 'Power5V':(['+5V','+5V_BUCK','+5V_SENS','VBUS_USB','CORE_5V'],750,180),
 'Power3V3':(['+3V3_EXT','CORE_3V3'],400,180),
 'Coil':(['COIL_PLUS','COIL_LOW'],500,180),
 'Ground':(['GND'],350,180),
 'USB':(['USB_DP','USB_DN'],200,180),
}
assigned={n for nets,w,c in classes.values() for n in nets}
classes['Default']=([n for n in netpins if n not in assigned],250,180)
for cls,(nets,w,c) in classes.items():
    out.append(f'  (class {cls} '+ ' '.join(q(n) for n in nets)+f' (circuit (use_via V600_300)) (rule (width {w}) (clearance {c})))')
out+=[' )',' (wiring']
for r in ROUTES:
    out.append(f'  (wire (path {"F.Cu" if r["layer"]==1 else "B.Cu"} {um(r["width"])} '+
               ' '.join(um(v) for xy in r['points'] for v in xy)+f') (net {q(r["net"])}) (type protect))')
for v in VIAS:
    if v['diameter']==.55:continue
    name='V550_300' if v['diameter']==.55 else 'V600_300'
    out.append(f'  (via {name} {um(v["x"])} {um(v["y"])} (net {q(v["net"])}) (type protect))')
out+=[' )',')']
(BASE/'carrier.dsn').write_text('\n'.join(out),encoding='ascii')
(BASE/'fixed-routes.json').write_text(json.dumps({'routes':ROUTES,'vias':VIAS},indent=2),encoding='utf-8')
print('DSN',len(PLACE),'parts',len(netpins),'nets',len(ROUTES),'fixed paths',len(VIAS),'fixed vias')
