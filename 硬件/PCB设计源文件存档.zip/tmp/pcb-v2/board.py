"""Physical design data and reproducible placement for the carrier board."""
import copy
import json
import math
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
DOCS=json.loads((ROOT/'tmp/import-repair/repaired-project.json').read_text(encoding='utf-8'))
PARTS=json.loads((ROOT/'tmp/import-repair/repaired-parts.json').read_text(encoding='utf-8'))
IDX={d['head']['uuid']:d for d in DOCS}
PART={p['ref']:p for p in PARTS}
# The local 1x8 pattern originally centred its body at pin 1 while its pads
# start at pin 1 and run to pin 8. Align its body with the pad-row midpoint.
fp8=IDX[PART['J13']['footprint_id']]
for r in fp8['records']:
    if r['h']['type']=='POLY' and r['b'].get('layerId') in [3,48]:
        path=r['b']['path']; nums=[i for i,v in enumerate(path) if isinstance(v,(int,float))]
        for i in nums[1::2]:path[i]+=8.89/.0254
WIDTH,HEIGHT=130,100
HOLES=[(5,5),(125,5),(5,95),(125,95)]
PLACE={}

def put(ref,x,y,a=0):
    assert ref in PART,ref
    assert ref not in PLACE,ref
    PLACE[ref]=(x,y,a)

# Edge connectors, with the core board in the same orientation as its drawing.
for ref,x,y,a in [
    ('J1',14,94,0),('J10',43,94,0),('J12',62,94,0),('J13',93,94,90),
    ('J11',107,94,0),('J18',124,83,90),('J4',124,72,90),('J21',124,58,90),
    ('J17',124,44,90),('J3',124,34,90),('J14',124,21,90),
    ('J20',109,6,0),('J7',92,6,0),('J6',75,6,0),('J16',60,6,0),
    ('J8',46,6,0),('J9',30,6,0),('J5',6,35,90),('J15',14.5,3.5,0),
    ('J2A',67,66.62,0),('J2B',67,51.38,0),('JP1',101,48.5,0),('SW1',38,39,0),
]: put(ref,x,y,a)

# Input branch and compact LMR36520 switching stage.
for ref,x,y,a in [
    ('F1',14,86,0),('D1',9.5,79,90),('D11',24,86,180),('C1',32,92,0),
    ('U1',25,76,0),('C4',19.5,78.135,90),('C23',15,78.135,90),
    ('C2',19.5,73,0),('L1',34,81.5,0),('C3',29.8,76.635,0),
    ('C5',41.2,81,0),('C6',40,76,0),('C24',29.8,74.4,0),
    ('R2',32.5,71.4,0),('R3',29,69.7,90),('R21',19.5,70.8,0),
    ('R22',23,70.8,0),('R31',26.5,70,0),
]: put(ref,x,y,a)

# Power OR, peripheral regulator and switched sensor supply.
for ref,x,y,a in [
    ('U3',45.5,79,0),('C25',50,79,0),('C26',45,75.5,0),('C40',47.8,81.5,90),
    ('U4',48,87,0),('C27',54,90,0),('C28',41.7,87.5,180),('C41',42.5,83.5,180),
    ('R32',54,83,0),('Q4',58,87,0),('Q5',63,87,0),('C50',58.6,91,180),
    ('R53',58,83,0),('R54',63,82.5,0),('R55',66,85,90),('R56',63,91,0),
]: put(ref,x,y,a)

# ADC filters outside the plug-in core outline, close to the upper pin row.
for ref,x,y,a in [
    ('R46',57.5,80,90),('R47',57.5,75.5,90),('C31',60,73.5,90),('D13',57.5,72.2,0),
    ('R30',64,80,90),('R15',64,75.5,90),('C10',66.5,73.5,90),('D8',64,72.2,0),
    ('R44',72,82,0),('R45',74.7,80,90),('R14',72,77.5,90),('C9',74.7,74.7,90),('D7',72,72,0),
    ('R10',79.7,82,90),('R11',82,79.5,90),('R12',79.7,77.5,90),('C7',82,74.7,90),('D5',79.7,72,0),
    ('R28',87.5,82,0),('R29',90.2,80,90),('R13',87.5,77.5,90),('C8',90.2,74.7,90),('D6',87.5,72,0),
]: put(ref,x,y,a)

# Watchdog, reset dominance, ARM latch, PWM gate and external coil driver.
for ref,x,y,a in [
    ('U5',99.5,78,0),('C42',97,79,90),('R35',98,74.5,0),
    ('U6',104,70,0),('C43',101.5,71,90),('R4',101.5,67,0),
    ('R33',116,71,90),('R34',116,68,0),('R5',113,66,90),('C29',110.5,66,90),
    ('U7',113.5,53,0),('C44',111,54,90),('R36',116,47.5,90),
    ('R37',113.5,49.5,90),('C30',110.8,50.5,90),
    ('U8',111,61.5,0),('C45',113.7,61.5,90),('U9',112,76,0),('C46',109.5,77,90),
    ('U10',114,37,0),('C47',111.5,38,90),('R39',110,34.5,90),
    ('R40',108,38,90),('R20',118.3,37.8,90),('R41',119.2,33,90),
    ('Q3',113,85,180),('R42',109.5,83.5,0),('R43',109.5,87,0),('D12',117.5,84,90),
]: put(ref,x,y,a)

# USB full speed and isolated UART buffers, kept away from the switching node.
for ref,x,y,a in [
    ('U2',15,18,90),('C21',22.5,15,0),('C22',23,19.3,0),
    ('R23',10.5,10,90),('R24',21.8,10,90),('U11',28,22,0),
    ('U12',28,29,0),('C48',25.5,23,90),('C49',25.5,30,90),
    ('R50',31.5,29,90),('R51',31.5,22,90),('R52',28,18.5,0),
]: put(ref,x,y,a)

# Human interfaces, pull resistors and outputs.
for ref,x,y,a in [
    ('R25',12,35,90),('R26',46,13,90),('R27',30,13,90),
    ('R16',99,89,90),('R17',102,89,90),('R18',63,89,0),('R19',87,89,0),
    ('R48',91,88,90),('R57',105.3,88.2,90),('R58',118,58,90),
    ('Q2',115,23,0),('R9',111.5,22,90),('R49',111.5,25,90),('D14',117,28,0),
    ('D3',12,46,0),('R8',16,46,0),('D4',12,51,0),('R6',16,51,0),
]: put(ref,x,y,a)
assert set(PLACE)==set(PART),(set(PART)-set(PLACE),set(PLACE)-set(PART))

def rot(x,y,angle):
    a=math.radians(angle)
    return(x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a))

def pads(ref,global_coords=True):
    p=PART[ref]
    fp=IDX[p['footprint_id']]
    out=[]
    for i,r in enumerate(r for r in fp['records'] if r['h']['type']=='PAD'):
        b=r['b']; x=b['centerX']*.0254; y=b['centerY']*.0254
        w=b['defaultPad']['width']*.0254;h=b['defaultPad']['height']*.0254
        ang=b.get('padAngle',0) or 0
        # Native libraries contain sub-micron rounding offsets; copper analysis
        # uses the hole-centre origin and tolerates these below 0.001 mm.
        assert abs(b.get('padOffsetX') or 0)<.04 and abs(b.get('padOffsetY') or 0)<.04
        if global_coords:
            px,py,a=PLACE[ref];x,y=rot(x,y,a);x+=px;y+=py;ang+=a
        hole=(b.get('hole') or {}).get('width',0)*.0254
        out.append(dict(ref=ref,number=b['num'],id=r['h']['id'],dsn_pin='p'+str(i+1),
                        x=x,y=y,w=w,h=h,angle=ang,shape=b['defaultPad']['padType'],
                        hole=hole,layers=[1,2] if b['layerId']==12 else [1],net=p['nets'][b['num']]))
    return out

def pin(ref,num):
    return next(p for p in pads(ref) if p['number']==str(num))

if __name__=='__main__':
    (BASE/'placement.json').write_text(json.dumps(PLACE,indent=2),encoding='utf-8')
    (BASE/'pads.json').write_text(json.dumps([p for r in PART for p in pads(r)],indent=2),encoding='utf-8')
    print('Placed',len(PLACE),'components; pads',sum(len(pads(r)) for r in PART))
