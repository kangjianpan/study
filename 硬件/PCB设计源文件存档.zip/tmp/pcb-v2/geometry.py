"""Independent copper geometry checks in millimetres."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'python-libs'))
from shapely.geometry import Point,LineString,box,Polygon
from shapely.affinity import rotate,translate,scale
from shapely.strtree import STRtree
from board import *

HV={'VIN_IN','VIN_F','VBAT'}

def pad_shape(p):
    if p['shape']=='ELLIPSE':
        shape=scale(Point(0,0).buffer(1,quad_segs=16),p['w']/2,p['h']/2)
    else:shape=box(-p['w']/2,-p['h']/2,p['w']/2,p['h']/2)
    return translate(rotate(shape,p['angle'],origin=(0,0)),p['x'],p['y'])

def body_shape(ref):
    if ref=='C1':
        x,y,a=PLACE[ref];return Point(x,y).buffer(5)
    fp=IDX[PART[ref]['footprint_id']]
    shapes=[]
    for r in fp['records']:
        b=r['b']
        if b.get('layerId')!=48:continue
        paths=b.get('path',[])
        if r['h']['type']=='POLY':paths=[paths]
        for path in paths:
            if not isinstance(path,list) or any(isinstance(v,str) and v!='L' for v in path):continue
            vals=[v*.0254 for v in path if isinstance(v,(int,float))]
            if len(vals)<8 or len(vals)%2:continue
            pts=list(zip(vals[::2],vals[1::2]))
            shape=Polygon(pts)
            if shape.is_valid and shape.area>.01:shapes.append(shape)
    if not shapes:
        # Body-only dimensions for the two LED patterns without an assembly outline.
        if ref in ['D3','D4']:shapes=[box(-1,-.625,1,.625)]
        else:raise ValueError('Missing body outline: '+ref)
    from shapely.ops import unary_union
    x,y,a=PLACE[ref]
    return translate(rotate(unary_union(shapes),a,origin=(0,0)),x,y)

def body_check():
    refs=list(PART);shapes=[body_shape(r) for r in refs]
    tree=STRtree(shapes);errors=[]
    for i,shape in enumerate(shapes):
        for j in tree.query(shape):
            if j>=i:continue
            area=shape.intersection(shapes[j]).area
            if area>.005:errors.append((refs[i],refs[j],round(area,4)))
    core=box(67-26.67,59-11.43,67+26.67,59+11.43)
    intrusions=[ref for ref,shape in zip(refs,shapes) if ref not in ['J2A','J2B'] and shape.intersects(core)]
    print('BODY_OVERLAPS',errors,'CORE_INTRUSIONS',intrusions)
    return errors,intrusions

def items(routes=(),vias=()):
    out=[]
    for ref in PART:
        for p in pads(ref):
            out.append(dict(name=ref+'.'+p['number'],ref=ref,net=p['net'] or 'NC_'+ref+'_'+p['number'],
                            shape=pad_shape(p),layers=p['layers'],type='pad',pad=p))
    for i,r in enumerate(routes):
        out.append(dict(name='route'+str(i)+'_'+r['net'],net=r['net'],
            shape=LineString(r['points']).buffer(r['width']/2,quad_segs=8),layers=[r['layer']],type='track'))
    for i,v in enumerate(vias):
        out.append(dict(name='via'+str(i)+'_'+v['net'],net=v['net'],
            shape=Point(v['x'],v['y']).buffer(v['diameter']/2,quad_segs=12),layers=[1,2],type='via'))
    return out

def clearance(a,b):return .5 if a['net'] in HV or b['net'] in HV else .18

def component_pad_check(objs,verbose=True):
    """Check assembly spacing across components, including equal-net pads."""
    ps=[o for o in objs if o['type']=='pad']
    tree=STRtree([o['shape'] for o in ps]);errors=[]
    for i,a in enumerate(ps):
        for j in tree.query(a['shape'].buffer(.51)):
            if j>=i:continue
            b=ps[j]
            if a['pad']['ref']==b['pad']['ref'] or not set(a['layers'])&set(b['layers']):continue
            need=clearance(a,b);gap=a['shape'].distance(b['shape'])
            if gap<need-.003:
                errors.append(dict(a=a['name'],b=b['name'],a_net=a['net'],b_net=b['net'],
                    gap_mm=round(gap,6),overlap_mm2=round(a['shape'].intersection(b['shape']).area,6),
                    required_mm=need))
    if verbose:print('CROSS_COMPONENT_PAD_SPACING',len(errors),errors)
    return errors

def check(objs,verbose=True):
    tree=STRtree([o['shape'] for o in objs]);errors=[]
    for i,a in enumerate(objs):
        for j in tree.query(a['shape'].buffer(.51)):
            if j>=i:continue
            b=objs[j]
            if a['net']==b['net'] or not set(a['layers'])&set(b['layers']):continue
            # Library internal pad gaps are checked too, including NCs.
            need=clearance(a,b)
            d=a['shape'].distance(b['shape'])
            if d<need-.003:
                errors.append((a['name'],b['name'],round(d,4),need))
    if verbose:print('COPPER_CLEARANCE',len(errors),errors[:65])
    return errors

if __name__=='__main__':
    fixed=json.loads((BASE/'fixed-routes.json').read_text(encoding='utf-8'))
    check(items(fixed['routes'],fixed['vias']))
    body_check()
