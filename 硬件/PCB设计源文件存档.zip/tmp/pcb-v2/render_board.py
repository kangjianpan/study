"""Render copper geometry and package body outlines for visual inspection."""
from geometry import *
from PIL import Image,ImageDraw,ImageFont

def render(routes=(),vias=(),filename='pcb-preview.png',labels=None,annotations=None):
    s=14;pad=70
    im=Image.new('RGB',(round(WIDTH*s)+2*pad,round(HEIGHT*s)+2*pad),'#e8ecef')
    dr=ImageDraw.Draw(im)
    def pt(x,y):return(pad+x*s,pad+(HEIGHT-y)*s)
    def poly(shape,fill=None,outline=None,w=1):
        if shape.geom_type=='Polygon':
            xy=[pt(x,y) for x,y in shape.exterior.coords]
            if fill:
                dr.polygon(xy,fill=fill)
                for ring in shape.interiors:
                    dr.polygon([pt(x,y) for x,y in ring.coords],fill='#164b36')
            if outline:dr.line(xy,fill=outline,width=w,joint='curve')
        elif hasattr(shape,'geoms'):
            for child in shape.geoms:poly(child,fill,outline,w)
    def text(x,y,value,size=1,color='#e9efe5',anchor='mm'):
        font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',max(9,round(size*s)))
        dr.text(pt(x,y),value,font=font,fill=color,anchor=anchor)
    dr.rectangle([pt(0,HEIGHT),pt(WIDTH,0)],fill='#164b36',outline='#1d2c25',width=3)
    if (BASE/'ground-plane.wkt').exists():
        from shapely import wkt
        poly(wkt.loads((BASE/'ground-plane.wkt').read_text(encoding='ascii')),fill='#255b46')
    for layer,color in [(2,'#37668c'),(1,'#d47b40')]:
        for r in routes:
            if r['layer']!=layer:continue
            dr.line([pt(x,y) for x,y in r['points']],fill=color,width=max(1,round(r['width']*s)),joint='curve')
    for ref in PART:poly(body_shape(ref),None,'#d8dfbf',max(1,round(.12*s)))
    for ref in PART:
        for p in pads(ref):
            poly(pad_shape(p),'#c7b56e')
            if p['hole']:
                x,y=pt(p['x'],p['y']);rad=p['hole']/2*s
                dr.ellipse((x-rad,y-rad,x+rad,y+rad),fill='#15221b')
    for v in vias:
        x,y=pt(v['x'],v['y']);r=v['diameter']/2*s
        dr.ellipse((x-r,y-r,x+r,y+r),fill='#b4a677')
        r=v['hole']/2*s;dr.ellipse((x-r,y-r,x+r,y+r),fill='#13291f')
    for x,y in HOLES:
        px,py=pt(x,y);r=3*s
        dr.ellipse((px-r,py-r,px+r,py+r),outline='#c8d1cb',width=1)
        r=1.6*s;dr.ellipse((px-r,py-r,px+r,py+r),fill='#e8ecef')
    # Outline and front orientation of the existing plug-in core.
    core=box(40.33,47.57,93.67,70.43)
    poly(core,None,'#79c1aa',2)
    text(67,60,'TLS STM32F103C8',2,'#8bd1bd')
    text(67,56.5,'PLUG-IN CORE / 15.24 mm',1.1,'#8bd1bd')
    text(40,59,'USB',.9,'#8bd1bd')
    for ref in PART:
        if labels and ref in labels:
            b=labels[ref];text(b['x'],b['y'],ref,b['size'])
        else:
            shape=body_shape(ref);x1,y1,x2,y2=shape.bounds
            text((x1+x2)/2,y2+.8,ref,.75)
    if annotations is not None:
        for a in annotations:text(a['x'],a['y'],a['text'],a['size'])
    text(65,103.2,'130 x 100 mm | 2 LAYERS | 4 x M3',1.5,'#182e22')
    im.save(BASE/filename)
    return BASE/filename

if __name__=='__main__':
    source=BASE/'preview-data.json'
    if not source.exists():source=BASE/'routed.json'
    if not source.exists():source=BASE/'fixed-routes.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    render(data['routes'],data['vias'],labels=data.get('labels'),annotations=data.get('annotations'))
