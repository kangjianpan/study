"""Repair the two confirmed assembly overlaps without rewriting other documents.

The saved before-design input also reproduces the old check's missed cases.
Already repaired archives are verified by verify_archive.py, not patched twice.
"""
import hashlib
import time
import uuid
import zipfile
from collections import Counter
from geometry import *
from import_ses import connectivity
from shapely.ops import unary_union
from shapely.geometry.polygon import orient

project=ROOT/'硬件/童骑卫-底板v2-PCB样机版.epro2'
assert project.resolve().is_relative_to(ROOT.resolve())
before_path=BASE/'pad-spacing-before-design.json'
if not before_path.exists():
    before_path.write_bytes((BASE/'final-design.json').read_bytes())
before=json.loads(before_path.read_text(encoding='utf-8'))
design=copy.deepcopy(before)
old_places={'C5':(40,81,0),'C50':(58,91,180)}

# Regression: the new rule must detect exactly the two original overlaps.
new_places={ref:PLACE[ref] for ref in old_places}
PLACE.update(old_places)
old_errors=component_pad_check(items(before['routes'],before['vias']))
assert {frozenset((e['a'],e['b'])) for e in old_errors}=={
    frozenset(('L1.2','C5.1')),frozenset(('C27.2','C50.2'))}
PLACE.update(new_places)

with zipfile.ZipFile(project) as z:
    assert z.testzip() is None
    files={n:z.read(n) for n in z.namelist()}
entry=next(n for n in files if n.endswith('.epru'))
docs=[]
for line in files[entry].decode('utf-8').splitlines():
    h,b=line.split('||',1);h=json.loads(h);b=json.loads(b[:-1])
    if h['type']=='DOCHEAD':docs.append({'head':b,'records':[]})
    docs[-1]['records'].append({'h':h,'b':b})
pcb=next(d for d in docs if d['head']['docType']=='PCB')
nonpcb=copy.deepcopy([d for d in docs if d is not pcb])
original_pcb=copy.deepcopy(pcb)
attrs={}
for r in pcb['records']:
    if r['h']['type']=='ATTR':attrs.setdefault(r['b']['parentId'],{})[r['b']['key']]=r['b']
for r in pcb['records']:
    if r['h']['type']!='COMPONENT':continue
    ref=attrs[r['h']['id']]['Designator']['value']
    if ref not in old_places:continue
    b=r['b'];actual=(b['x']*.0254,b['y']*.0254,b['angle'])
    assert max(abs(a-b) for a,b in zip(actual,old_places[ref]))<.0001,(ref,actual,'Expected original placement')
    x,y,a=PLACE[ref];b.update(x=round(x/.0254,5),y=round(y/.0254,5),angle=a)

# Move every route endpoint attached to the moved capacitor terminals.
for route in design['routes']:
    for xy in route['points']:
        if xy in [[38.5,81.0],[41.5,81.0]]:xy[0]=round(xy[0]+1.2,6)
        elif xy in [[56.5,91.0],[59.5,91.0]]:xy[0]=round(xy[0]+.6,6)

# Reroute ESP_RX between C5's terminals and left of C41's ground branch.
assert before['routes'][265]['net']=='ESP_RX'
assert before['routes'][264]['net']=='ESP_RX'
assert before['routes'][708]['net']=='+5V_BUCK'
design['routes'][265]['points']=[[40.493,72.912],[40.493,78.8],[41,79.307],[41,84.5]]
design['routes'][264]['points']=[[41,84.5],[41.914,85.414],[41.914,91.644],[44.27,94.0]]
design['routes'][708]['points']=[[39.7,81],[38.8,81.9],[38.8,84.7]]

def segments(r):
    return [dict(net=r['net'],layer=r['layer'],width=r['width'],points=[a,b])
            for a,b in zip(r['points'],r['points'][1:]) if a!=b]

def key(r):
    ends=sorted(tuple(round(v,5) for v in xy) for xy in r['points'])
    return (r['net'],r['layer'],round(r['width'],5),tuple(ends))

changed=[i for i,(a,b) in enumerate(zip(before['routes'],design['routes'])) if a!=b]
old_segments=[s for i in changed for s in segments(before['routes'][i])]
old_keys=Counter(key(s) for s in old_segments)
removed=Counter()
kept=[]
for r in pcb['records']:
    b=r['b']
    if r['h']['type']=='LINE' and b['layerId'] in [1,2]:
        k=key(dict(net=b['netName'],layer=b['layerId'],width=b['width']*.0254,
            points=[[b['startX']*.0254,b['startY']*.0254],[b['endX']*.0254,b['endY']*.0254]]))
        if k in old_keys:removed[k]+=1;continue
    kept.append(r)
assert removed==old_keys,(removed-old_keys,old_keys-removed)
pcb['records']=kept

def mil(v):return round(v/.0254,5)
for i in changed:
    for s in segments(design['routes'][i]):
        a,b=s['points']
        pcb['records'].append({'h':{'type':'LINE','id':uuid.uuid4().hex[:16]},'b':dict(
            partitionId='',groupId=0,netName=s['net'],layerId=s['layer'],startX=mil(a[0]),
            startY=mil(a[1]),endX=mil(b[0]),endY=mil(b[1]),width=mil(s['width']),locked=False,zIndex=1)})

# Smaller Q4 reference preserves clearance to C50's new ground pad.
design['labels']['Q4']['size']=.75
for a in attrs.values():
    if a.get('Designator',{}).get('value')=='Q4':a['Designator']['fontSize']=mil(.75)

objs=items(design['routes'],design['vias'])
assert not check(objs)
assert not component_pad_check(objs)
assert not connectivity(objs)
assert body_check()==([],[])

# Rebuild the bottom plane with the same clearances and thermal reliefs.
cutters=[o['shape'].buffer(.55 if o['net'] in HV else .24,quad_segs=8)
         for o in objs if 2 in o['layers'] and o['net']!='GND']
cutters.extend(Point(x,y).buffer(3.2,quad_segs=24) for x,y in HOLES)
cutters.append(box(27,77.3,34.6,85.5))
plane=box(.5,.5,WIDTH-.5,HEIGHT-.5).difference(unary_union(cutters))
for o in objs:
    if o['type']!='pad' or o['net']!='GND' or not o['pad']['hole']:continue
    p=o['pad'];x,y=p['x'],p['y'];reach=max(p['w'],p['h'])/2+.7
    spokes=unary_union([box(x-reach,y-.2,x+reach,y+.2),box(x-.2,y-reach,x+.2,y+reach)])
    plane=plane.difference(o['shape'].buffer(.35).difference(spokes))
plane=plane.buffer(-.12,quad_segs=4).buffer(.12,quad_segs=4).simplify(.005,preserve_topology=True)
gnd=unary_union([o['shape'] for o in objs if o['net']=='GND' and 2 in o['layers']])
regions=list(plane.geoms) if hasattr(plane,'geoms') else [plane]
regions=[orient(p,1) for p in regions if p.area>1 and p.intersects(gnd)]
plane=unary_union(regions)
assert plane.is_valid
planeitem=dict(name='GND_plane',net='GND',layers=[2],type='plane',shape=plane)
assert not check(objs+[planeitem])
assert not connectivity(objs+[planeitem])

def path(poly):
    loops=[]
    for ring in [poly.exterior,*poly.interiors]:
        xy=list(ring.coords)
        loops.append([mil(xy[0][0]),mil(xy[0][1]),'L',*[mil(v) for pt in xy[1:] for v in pt]])
    return loops

fills=[r for r in pcb['records'] if r['h']['type']=='POURED']
assert len(fills)==1
fills[0]['b']['pourFill']=[dict(id=uuid.uuid4().hex[:16],strokeWidth=0,fill=True,path=path(p)) for p in regions]

# Assert only the two components, one reference and touched copper have changed.
affected_ids={r['h']['id'] for r in original_pcb['records'] if r['h']['type']=='LINE' and
              r['h']['id'] not in {x['h'].get('id') for x in pcb['records']}}
affected_ids.update(r['h']['id'] for r in pcb['records'] if r['h']['type']=='POURED')
affected_ids.update(r['h']['id'] for r in pcb['records'] if r['h']['type']=='COMPONENT' and
                    attrs[r['h']['id']]['Designator']['value'] in old_places)
affected_ids.update(r['h']['id'] for r in pcb['records'] if r['h']['type']=='ATTR' and
                    r['b'].get('key')=='Designator' and r['b'].get('value')=='Q4')
remaining={(r['h']['type'],r['h'].get('id')):r for r in pcb['records']}
for r in original_pcb['records']:
    if r['h'].get('id') not in affected_ids:assert r==remaining[r['h']['type'],r['h'].get('id')]

pcb['head'].update(updateTime=int(time.time()*1000),version=str(int(time.time()*1000)))
for i,r in enumerate(pcb['records'],1):r['h']['ticket']=i;r['h'].pop('firstTicket',None)
assert [d for d in docs if d is not pcb]==nonpcb
raw='\n'.join(json.dumps(r['h'],ensure_ascii=False,separators=(',',':'))+'||'+
              json.dumps(r['b'],ensure_ascii=False,separators=(',',':'))+'|'
              for d in docs for r in d['records'])+'\n'
old_hash=hashlib.sha256(project.read_bytes()).hexdigest()
files[entry]=raw.encode('utf-8')
with zipfile.ZipFile(project,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
(BASE/'final.epru').write_bytes(raw.encode('utf-8'))
(BASE/'ground-plane.wkt').write_text(plane.wkt,encoding='ascii')
(BASE/'final-design.json').write_text(json.dumps(design,indent=2),encoding='utf-8')
(BASE/'routed.json').write_text(json.dumps({k:design[k] for k in ['routes','vias']},indent=2),encoding='utf-8')

pairs=[]
for a,b in [('L1.2','C5.1'),('C27.2','C50.2')]:
    aa=next(o for o in objs if o['name']==a);bb=next(o for o in objs if o['name']==b)
    pairs.append(dict(a=a,b=b,gap_mm=round(aa['shape'].distance(bb['shape']),6)))
report=dict(before_sha256=old_hash,sha256=hashlib.sha256(project.read_bytes()).hexdigest(),
    placements_before_mm=old_places,placements_after_mm=new_places,old_overlap_cases=old_errors,
    repaired_pad_gaps=pairs,changed_route_groups=changed,removed_track_segments=sum(removed.values()),
    added_track_segments=sum(len(segments(design['routes'][i])) for i in changed),
    schematic_and_library_documents_unchanged=True,all_other_components_and_pad_nets_unchanged=True,
    limits='Independent geometry checks; official editor DRC and assembly checks remain pending.')
(BASE/'pad-spacing-repair.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
