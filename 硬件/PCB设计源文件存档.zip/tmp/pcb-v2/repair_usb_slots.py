"""Apply local USB-C alignment-hole rerouting to an editor-saved native project.

Preserve the user's schematic-to-PCB synchronization and every unrelated record.
The original route geometry is matched by coordinates, not editor object IDs.
"""
import hashlib
import time
import uuid
import zipfile
from collections import Counter
from geometry import *
from import_ses import connectivity
from shapely.ops import unary_union
from shapely.geometry.polygon import orient

project=ROOT/'硬件/童骑卫-底板v2-PCB样机版.epro2'
assert project.resolve().is_relative_to(ROOT.resolve())
before_path=BASE/'usb-slot-before-design.json'
if not before_path.exists():before_path.write_bytes((BASE/'final-design.json').read_bytes())
before=json.loads(before_path.read_text(encoding='utf-8'))
design=copy.deepcopy(before)
updates={
    104:[[10.7,5.808],[10.7,4],[10.2,3.5],[18.8,3.5],[18.8,5.391]],
    105:[[10.522,5.391],[10.7,5.569],[10.7,5.808]],
    237:[[17.7,5.808],[18.25,5.808],[18.667,5.391],[18.8,5.391]],
    238:[[18.8,5.391],[19.7,5.391]],
    240:[[11.3,5.808],[10.7,5.808]],
    256:[[6,31.19],[6,11.162],[2,7.162],[2,2],[25.484,2],[26.19,4.104]],
    502:[[16.9,5.808],[16.9,5.3]],
    503:[[16.9,5.3],[16.4,4.8],[15.582,4.8],[15.456,4.674]],
}
for i,ps in updates.items():design['routes'][i]['points']=ps
# Short fine-pitch escape, followed by the unchanged wider USB supply path.
for i in [502,503]:design['routes'][i]['width']=.25
baseline_segments=[dict(r,points=[a,b]) for r in before['routes']
                   for a,b in zip(r['points'],r['points'][1:]) if a!=b]
baseline_errors=slot_check(items(baseline_segments,before['vias']))
assert len(baseline_errors)==11 and all(e['type']=='track' for e in baseline_errors)

def segments(route):
    return [dict(net=route['net'],layer=route['layer'],width=route['width'],points=[a,b])
            for a,b in zip(route['points'],route['points'][1:]) if a!=b]
def key(s):
    ends=tuple(sorted(tuple(round(v,4) for v in xy) for xy in s['points']))
    return (s['net'],s['layer'],round(s['width'],4),ends)
def native_route(b):
    return dict(net=b['netName'],layer=b['layerId'],width=b['width']*.0254,
                points=[[b['startX']*.0254,b['startY']*.0254],[b['endX']*.0254,b['endY']*.0254]])
def mil(v):return round(v/.0254,5)

with zipfile.ZipFile(project) as z:
    assert z.testzip() is None
    files={n:z.read(n) for n in z.namelist()}
entry=next(n for n in files if n.endswith('.epru'))
docs=[]
for line in files[entry].decode('utf-8').splitlines():
    h,b=line.split('||',1);h=json.loads(h)
    b=None if b=='|' else json.JSONDecoder().raw_decode(b)[0]
    if h['type']=='DOCHEAD':docs.append({'head':b,'records':[]})
    if b is not None:docs[-1]['records'].append({'h':h,'b':b})
pcb=next(d for d in docs if d['head']['docType']=='PCB')
nonpcb=copy.deepcopy([d for d in docs if d is not pcb])
original_pcb=copy.deepcopy(pcb)
baseline_keys=Counter(key(s) for r in before['routes'] for s in segments(r))
native_keys=Counter(key(native_route(r['b'])) for r in pcb['records']
                    if r['h']['type']=='LINE' and r['b']['layerId'] in [1,2])
assert baseline_keys==native_keys,('Editor copper changed; inspect before merging',native_keys-baseline_keys,baseline_keys-native_keys)
changed=[i for i in updates]
old_keys=Counter(key(s) for i in changed for s in segments(before['routes'][i]))
removed=Counter();removed_ids=set();kept=[]
for r in pcb['records']:
    b=r['b']
    if r['h']['type']=='LINE' and b['layerId'] in [1,2]:
        k=key(native_route(b))
        if k in old_keys:
            removed[k]+=1;removed_ids.add(r['h']['id']);continue
    kept.append(r)
assert old_keys==removed,(old_keys-removed,removed-old_keys)
pcb['records']=kept
for i in changed:
    for s in segments(design['routes'][i]):
        a,b=s['points']
        pcb['records'].append(dict(h=dict(type='LINE',id=uuid.uuid4().hex[:16]),b=dict(
            partitionId='',groupId=0,netName=s['net'],layerId=s['layer'],startX=mil(a[0]),
            startY=mil(a[1]),endX=mil(b[0]),endY=mil(b[1]),width=mil(s['width']),locked=False,zIndex=1)))

objs=items(design['routes'],design['vias']);slots=footprint_slots(docs)
assert not check(objs)
assert not component_pad_check(objs)
assert not slot_check(objs,slots)
assert not connectivity(objs)
assert body_check()==([],[])

planes={};regions_by_layer={};planeitems=[]
for layer in [1,2]:
    cutters=[o['shape'].buffer(.55 if o['net'] in HV else .24,quad_segs=8)
             for o in objs if layer in o['layers'] and o['net']!='GND']
    cutters.extend(Point(x,y).buffer(3.2,quad_segs=24) for x,y in HOLES)
    cutters.extend(s['shape'].buffer(.35) for s in slots)
    cutters.append(box(27,77.3,34.6,85.5))
    plane=box(.5,.5,WIDTH-.5,HEIGHT-.5).difference(unary_union(cutters))
    for o in objs:
        if o['type']!='pad' or o['net']!='GND' or not o['pad']['hole']:continue
        p=o['pad'];x,y=p['x'],p['y'];reach=max(p['w'],p['h'])/2+.7
        spokes=unary_union([box(x-reach,y-.2,x+reach,y+.2),box(x-.2,y-reach,x+.2,y+reach)])
        plane=plane.difference(o['shape'].buffer(.35).difference(spokes))
    plane=plane.buffer(-.12,quad_segs=4).buffer(.12,quad_segs=4).simplify(.005,preserve_topology=True)
    gnd=unary_union([o['shape'] for o in objs if o['net']=='GND' and layer in o['layers']])
    regions=list(plane.geoms) if hasattr(plane,'geoms') else [plane]
    regions=[orient(p,1) for p in regions if p.area>1 and p.intersects(gnd)]
    planes[layer]=unary_union(regions);regions_by_layer[layer]=regions
    assert planes[layer].is_valid
    planeitems.append(dict(name='GND_plane_'+str(layer),net='GND',layers=[layer],type='plane',shape=planes[layer]))
assert not check(objs+planeitems)
assert not slot_check(objs+planeitems,slots)
assert not connectivity(objs+planeitems)
assert all(box(.25,.25,129.75,99.75).covers(o['shape']) for o in objs+planeitems)
assert all(o['shape'].distance(Point(x,y))>=1.85-.001 for o in objs+planeitems for x,y in HOLES)
def path(poly):
    loops=[]
    for ring in [poly.exterior,*poly.interiors]:
        xy=list(ring.coords)
        loops.append([mil(xy[0][0]),mil(xy[0][1]),'L',*[mil(v) for pt in xy[1:] for v in pt]])
    return loops
old_pours=[r for r in pcb['records'] if r['h']['type']=='POUR']
assert len(old_pours)==3 and all(r['b']['netName']=='GND' for r in old_pours)
keep_pours={}
for r in old_pours:keep_pours.setdefault(r['b']['layerId'],r)
assert set(keep_pours)=={1,2}
pour_ids={r['h']['id'] for r in keep_pours.values()}
pcb['records']=[r for r in pcb['records'] if not (
    r['h']['type']=='POUR' and r['h']['id'] not in pour_ids or
    r['h']['type']=='POURED' and json.loads(r['h']['id'])[1] not in pour_ids)]
for layer,pour in keep_pours.items():
    pour['b'].update(name='GND_top' if layer==1 else 'GND_bottom',width=mil(.25),order=1,
        path=[mil(.5),mil(.5),'L',mil(WIDTH-.5),mil(.5),mil(WIDTH-.5),mil(HEIGHT-.5),mil(.5),mil(HEIGHT-.5),mil(.5),mil(.5)])
    fill=next(r for r in pcb['records'] if r['h']['type']=='POURED' and json.loads(r['h']['id'])[1]==pour['h']['id'])
    fill['b']['pourFill']=[dict(id=uuid.uuid4().hex[:16],strokeWidth=0,fill=True,path=path(p)) for p in regions_by_layer[layer]]

# This local repair cannot undo a user's Import Changes action.
remaining={(r['h']['type'],r['h'].get('id')):r for r in pcb['records']}
for r in original_pcb['records']:
    if r['h']['type'] in ['POURED','POUR'] or r['h'].get('id') in removed_ids:continue
    assert r==remaining[r['h']['type'],r['h'].get('id')]
pcb['head'].update(updateTime=int(time.time()*1000),version=str(int(time.time()*1000)))
for i,r in enumerate(pcb['records'],1):r['h']['ticket']=i;r['h'].pop('firstTicket',None)
assert nonpcb==[d for d in docs if d is not pcb]
# Local Save As changed sheet UUIDs but retained the old default-sheet pointer.
sheet=next(d for d in docs if d['head']['docType']=='SCH_PAGE')
config=next(d for d in docs if d['head']['docType']=='CONFIG')
config_meta=next(r['b'] for r in config['records'] if r['h']['type']=='META')
config_meta['defaultSheet']=sheet['head']['uuid']
raw='\n'.join(json.dumps(r['h'],ensure_ascii=False,separators=(',',':'))+'||'+
              json.dumps(r['b'],ensure_ascii=False,separators=(',',':'))+'|'
              for d in docs for r in d['records'])+'\n'
old_hash=hashlib.sha256(project.read_bytes()).hexdigest()
files[entry]=raw.encode('utf-8')
with zipfile.ZipFile(project,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
(BASE/'final.epru').write_bytes(raw.encode('utf-8'))
(BASE/'ground-plane.wkt').write_text(planes[2].wkt,encoding='ascii')
(BASE/'ground-plane-top.wkt').write_text(planes[1].wkt,encoding='ascii')
(BASE/'final-design.json').write_text(json.dumps(design,indent=2),encoding='utf-8')
(BASE/'routed.json').write_text(json.dumps({k:design[k] for k in ['routes','vias']},indent=2),encoding='utf-8')
clearances=[dict(slot=s['name'],minimum_track_clearance_mm=round(min(s['shape'].distance(o['shape'])
            for o in objs if o['type']=='track'),6)) for s in slots]
report=dict(before_sha256=old_hash,sha256=hashlib.sha256(project.read_bytes()).hexdigest(),
    original_slot_to_track_errors=baseline_errors,repaired_slot_clearances=clearances,
    schematic_library_components_padnets_unchanged=True,changed_route_groups=changed,
    removed_track_segments=sum(removed.values()),added_track_segments=sum(len(segments(design['routes'][i])) for i in changed),
    slot_to_copper_clearance_mm=.3,ground_plane_slot_clearance_mm=.35,
    ground_pours_before=3,ground_pours_after=2,ground_regions={layer:len(regions) for layer,regions in regions_by_layer.items()},
    project_default_sheet_reference_repaired=True,
    limits='Independent native archive geometry; user must rerun online editor DRC after importing.')
(BASE/'usb-slot-repair.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
