"""Re-open the final delivery, rebuild copper and check its physical net graph."""
import hashlib
import zipfile
from geometry import *
from import_ses import connectivity
from shapely.ops import unary_union

output=ROOT/'童骑卫-底板v2-PCB样机版.epro2'
docs=[]
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    raw=z.read(next(n for n in z.namelist() if n.endswith('.epru'))).decode('utf-8')
for l in raw.splitlines():
    h,b=l.split('||',1);h=json.loads(h);b=json.loads(b[:-1])
    if h['type']=='DOCHEAD':docs.append({'head':b,'records':[]})
    docs[-1]['records'].append({'h':h,'b':b})
ix={d['head']['uuid']:d for d in docs}
assert len(ix)==len(docs)
pcb=next(d for d in docs if d['head']['docType']=='PCB')
attrs={}
for r in pcb['records']:
    if r['h']['type']=='ATTR':attrs.setdefault(r['b']['parentId'],{})[r['b']['key']]=r['b']
native_positions={}
refcid={}
for r in pcb['records']:
    if r['h']['type']!='COMPONENT':continue
    b=r['b'];cid=r['h']['id'];ref=attrs[cid]['Designator']['value']
    refcid[ref]=cid
    native_positions[ref]=(b['x']*.0254,b['y']*.0254,b['angle'])
    assert max(abs(a-b) for a,b in zip(native_positions[ref],PLACE[ref]))<.0001,ref
assert set(native_positions)==set(PART)
padnets={}
for r in pcb['records']:
    if r['h']['type']=='PAD_NET':
        tag,cid,num,pid=json.loads(r['h']['id']);padnets[cid,num,pid]=r['b']['padNet'] or None

shapes=[]
for ref,p in PART.items():
    assert attrs[refcid[ref]]['Footprint']['value']==p['footprint_id']
    fp=ix[p['footprint_id']]
    fp_pads=[r for r in fp['records'] if r['h']['type']=='PAD']
    pads_reference={a['id']:a for a in pads(ref)}
    for r in fp_pads:
        b=r['b'];pre=pads_reference[r['h']['id']]
        net=padnets[refcid[ref],b['num'],r['h']['id']]
        assert net==p['nets'][b['num']]
        x,y=rot(b['centerX']*.0254,b['centerY']*.0254,native_positions[ref][2])
        pp=dict(pre,x=x+native_positions[ref][0],y=y+native_positions[ref][1],
                w=b['defaultPad']['width']*.0254,h=b['defaultPad']['height']*.0254,
                angle=b['padAngle']+native_positions[ref][2])
        assert pad_shape(pp).hausdorff_distance(pad_shape(pre))<.0001
        shapes.append(dict(name=ref+'.'+b['num'],net=net or 'NC_'+ref+'_'+b['num'],
                           shape=pad_shape(pp),layers=pre['layers'],type='pad',pad=pp))
routes=[];vias=[];holes=[];plane_regions=[]
for r in pcb['records']:
    b=r['b'];t=r['h']['type']
    if t=='LINE' and b['layerId'] in [1,2]:
        route=dict(net=b['netName'],layer=b['layerId'],width=b['width']*.0254,
            points=[(b['startX']*.0254,b['startY']*.0254),(b['endX']*.0254,b['endY']*.0254)])
        routes.append(route)
        shapes.append(dict(name=r['h']['id'],type='track',net=route['net'],layers=[route['layer']],
                      shape=LineString(route['points']).buffer(route['width']/2,quad_segs=8)))
    elif t=='VIA':
        v=dict(net=b['netName'],x=b['centerX']*.0254,y=b['centerY']*.0254,
               diameter=b['viaDiameter']*.0254,hole=b['holeDiameter']*.0254)
        vias.append(v)
        shapes.append(dict(name=r['h']['id'],type='via',net=v['net'],layers=[1,2],
                      shape=Point(v['x'],v['y']).buffer(v['diameter']/2,quad_segs=12)))
    elif t=='PAD':
        assert not b['plated']
        assert abs(b['hole']['width']*.0254-3.2)<.0001
        holes.append((b['centerX']*.0254,b['centerY']*.0254))
    elif t=='POURED':
        tag,pid=json.loads(r['h']['id'])
        pour=next(z['b'] for z in pcb['records'] if z['h'].get('id')==pid)
        assert pour['netName']=='GND' and pour['layerId']==2
        for region in b['pourFill']:
            loops=[]
            for loop in region['path']:
                vals=[v*.0254 for v in loop if isinstance(v,(int,float))]
                loops.append(list(zip(vals[::2],vals[1::2])))
            poly=Polygon(loops[0],loops[1:]);assert poly.is_valid
            plane_regions.append(poly)
            shapes.append(dict(name=region['id'],type='plane',net='GND',layers=[2],shape=poly))
assert len(holes)==4 and all(any(abs(x-a)<.0001 and abs(y-b)<.0001 for a,b in HOLES) for x,y in holes)
outline=next(r['b']['path'] for r in pcb['records'] if r['h']['type']=='POLY' and r['b'].get('layerId')==11)
assert abs(outline[3]*.0254-130)<.0001 and abs(outline[6]*.0254-100)<.0001
errors=check(shapes)
missing=connectivity(shapes)
assert not errors,errors[:10]
assert not missing,missing

# Mechanical and fabrication limits on delivered copper.
inside=box(.25,.25,129.75,99.75)
edge_errors=[o['name'] for o in shapes if not inside.covers(o['shape'])]
hole_errors=[o['name'] for o in shapes if any(o['shape'].distance(Point(x,y))<1.6+.25-.001 for x,y in holes)]
assert not edge_errors,edge_errors
assert not hole_errors,hole_errors
design=json.loads((BASE/'final-design.json').read_text(encoding='utf-8'))
assert len(routes)==sum(a!=b for r in design['routes'] for a,b in zip(r['points'],r['points'][1:]))
assert len(vias)==len(design['vias'])==147

result=dict(components=139,symbol_pins=427,footprint_pads=430,nets=81,board_mm=[130,100],
            copper_layers=2,tracks=len(routes),vias=len(vias),mounting_holes_mm=3.2,
            mounting_hole_centres_mm=HOLES,ground_regions=len(plane_regions),
            ground_area_mm2=unary_union(plane_regions).area,clearance_errors=0,unconnected_nets=0,
            edge_errors=0,mounting_hole_copper_errors=0,core_row_spacing_mm=15.24,
            mechanical_body_overlaps=0,core_body_intrusions=0,
            limits='Independent archive/copper/connectivity/geometry checks. Online editor display, official ERC/DRC, assembly and hardware tests remain pending.',
            sha256=hashlib.sha256(output.read_bytes()).hexdigest())
(BASE/'archive-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(BASE/'preview-data.json').write_text(json.dumps({'routes':routes,'vias':vias,
    'labels':{ref:{'x':attrs[cid]['Designator']['x']*.0254,'y':attrs[cid]['Designator']['y']*.0254,
                   'size':attrs[cid]['Designator']['fontSize']*.0254} for ref,cid in refcid.items()},
    'annotations':[{**r['b'],'x':r['b']['x']*.0254,'y':r['b']['y']*.0254,'size':r['b']['fontSize']*.0254}
                   for r in pcb['records'] if r['h']['type']=='STRING' and r['b']['layerId']==3]},indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
