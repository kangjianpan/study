"""Compare a resized board with its original synchronized electrical design."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path


def read_archive(path):
    docs = []
    with zipfile.ZipFile(path) as archive:
        raw = archive.read(next(n for n in archive.namelist() if n.endswith('.epru')))
    for line in raw.decode('utf-8').splitlines():
        header, body = line.split('||', 1)
        header, body = json.loads(header), json.loads(body[:-1])
        if header['type'] == 'DOCHEAD':
            docs.append({'head': body, 'records': []})
        docs[-1]['records'].append({'h': header, 'b': body})
    return {doc['head']['uuid']: doc for doc in docs}


def records(doc, types=None):
    return {record['h']['id']: (record['h']['type'], record['b'])
            for record in doc['records']
            if record['h']['type'] != 'DOCHEAD'
            and (types is None or record['h']['type'] in types)}


before, after = map(Path, sys.argv[1:3])
old, new = read_archive(before), read_archive(after)
assert old.keys() == new.keys(), 'Project document IDs changed'
for uuid, doc in old.items():
    replacement = new[uuid]
    assert doc['head']['docType'] == replacement['head']['docType']
    kind = doc['head']['docType']
    if kind == 'PCB':
        assert records(doc, {'PAD_NET', 'NET'}) == records(replacement, {'PAD_NET', 'NET'})
        components = records(doc, {'COMPONENT'})
        updated = records(replacement, {'COMPONENT'})
        assert components.keys() == updated.keys()
        for cid, (tag, data) in components.items():
            other = updated[cid][1]
            ignored = {'x', 'y', 'angle', 'locked'}
            assert {k: v for k, v in data.items() if k not in ignored} == {
                k: v for k, v in other.items() if k not in ignored}, cid
        attributes = records(doc, {'ATTR'})
        updated = records(replacement, {'ATTR'})
        assert attributes.keys() == updated.keys()
        for aid, (_, data) in attributes.items():
            for key in ['key', 'value', 'parentId']:
                assert data.get(key) == updated[aid][1].get(key), (aid, key)
    elif kind == 'FOOTPRINT':
        assert records(doc, {'PAD'}) == records(replacement, {'PAD'}), uuid
    else:
        assert records(doc) == records(replacement), (kind, uuid)

result = {
    'baseline_git_commit': 'bb92d64',
    'baseline_sha256': hashlib.sha256(before.read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(after.read_bytes()).hexdigest(),
    'schematic_and_non_pcb_records_identical': True,
    'component_ids_and_electrical_attributes_identical': True,
    'footprint_pad_definitions_identical': True,
    'pcb_pad_nets_identical': True,
    'limits': 'Electrical data equivalence only; physical routing is checked separately.'
}
Path(__file__).with_name('electrical-equivalence.json').write_text(
    json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
