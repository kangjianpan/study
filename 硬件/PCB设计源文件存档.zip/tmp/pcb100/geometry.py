"""Independent copper geometry checks in millimetres."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/'pcb-v2/python-libs'))
from shapely.geometry import Point,LineString,box,Polygon
from shapely.affinity import rotate,translate,scale
from shapely.strtree import STRtree
from board import *

HV={'VIN_IN','VIN_F','VBAT'}

def pad_shape(p):
    if p['shape']=='ELLIPSE':
        shape=scale(Point(0,0).buffer(1,quad_segs=16),p['w']/2,p['h']/2)
    else:shape=box(-p['w']/2,-p['h']/2,p['w']/2,p['h']/2)
    return translate(rotate(shape,p['angle'],origin=(0,0)),p['x'],p['y'])

def footprint_slots(docs=None,positions=None):
    """Mechanical through-cut regions reserve copper on both layers."""
    ix=IDX if docs is None else {d['head']['uuid']:d for d in docs}
    positions=PLACE if positions is None else positions
    out=[]
    for ref,part in PART.items():
        for r in ix[part['footprint_id']]['records']:
            b=r['b']
            if r['h']['type']!='FILL' or b.get('layerId')!=12:continue
            loops=b['path']
            assert len(loops)==1,('Unsupported mechanical cutout',ref,r['h'])
            path=loops[0]
            assert len(path)==10 and path[2:4]==['ARC',180] and path[6:8]==['ARC',180],(ref,path)
            assert abs(path[1]-path[5])<.001 and path[:2]==path[8:10],(ref,path)
            cx=(path[0]+path[4])/2*.0254;cy=path[1]*.0254
            radius=abs(path[0]-path[4])/2*.0254
            x,y,a=positions[ref];cx,cy=rot(cx,cy,a)
            out.append(dict(name=ref+'.'+r['h']['id'],ref=ref,layers=[1,2],
                            shape=Point(cx+x,cy+y).buffer(radius,quad_segs=64)))
    return out

def slot_check(objs,slots=None,verbose=True):
    slots=footprint_slots() if slots is None else slots
    errors=[]
    for slot in slots:
        for o in objs:
            if o['type']=='pad' and o['pad']['ref']==slot['ref']:continue
            if not set(o['layers'])&set(slot['layers']):continue
            d=slot['shape'].distance(o['shape'])
            if d<.3-.001:errors.append(dict(slot=slot['name'],object=o['name'],type=o['type'],gap_mm=round(d,6),required_mm=.3))
    if verbose:print('MECHANICAL_SLOT_CLEARANCE',len(errors),errors[:20])
    return errors

def body_shape(ref):
    if ref=='C1':
        x,y,a=PLACE[ref];return Point(x,y).buffer(5)
    fp=IDX[PART[ref]['footprint_id']]
    shapes=[]
    for r in fp['records']:
        b=r['b']
        if b.get('layerId')!=48:continue
        paths=b.get('path',[])
        if r['h']['type']=='POLY':paths=[paths]
        for path in paths:
            if not isinstance(path,list) or any(isinstance(v,str) and v!='L' for v in path):continue
            vals=[v*.0254 for v in path if isinstance(v,(int,float))]
            if len(vals)<8 or len(vals)%2:continue
            pts=list(zip(vals[::2],vals[1::2]))
            shape=Polygon(pts)
            if shape.is_valid and shape.area>.01:shapes.append(shape)
    if not shapes:
        # Body-only dimensions for the two LED patterns without an assembly outline.
        if ref in ['D3','D4']:shapes=[box(-1,-.625,1,.625)]
        else:raise ValueError('Missing body outline: '+ref)
    from shapely.ops import unary_union
    x,y,a=PLACE[ref]
    return translate(rotate(unary_union(shapes),a,origin=(0,0)),x,y)

def body_check():
    refs=list(PART);shapes=[body_shape(r) for r in refs]
    tree=STRtree(shapes);errors=[]
    for i,shape in enumerate(shapes):
        for j in tree.query(shape):
            if j>=i:continue
            area=shape.intersection(shapes[j]).area
            if area>.005:errors.append((refs[i],refs[j],round(area,4)))
    core=box(CORE_X-26.67,CORE_Y-11.43,CORE_X+26.67,CORE_Y+11.43)
    intrusions=[ref for ref,shape in zip(refs,shapes) if ref not in ['J2A','J2B'] and shape.intersects(core)]
    print('BODY_OVERLAPS',errors,'CORE_INTRUSIONS',intrusions)
    return errors,intrusions

def items(routes=(),vias=()):
    out=[]
    for ref in PART:
        for p in pads(ref):
            out.append(dict(name=ref+'.'+p['number'],ref=ref,net=p['net'] or 'NC_'+ref+'_'+p['number'],
                            shape=pad_shape(p),layers=p['layers'],type='pad',pad=p))
    for i,r in enumerate(routes):
        out.append(dict(name='route'+str(i)+'_'+r['net'],net=r['net'],
            shape=LineString(r['points']).buffer(r['width']/2,quad_segs=8),layers=[r['layer']],type='track'))
    for i,v in enumerate(vias):
        out.append(dict(name='via'+str(i)+'_'+v['net'],net=v['net'],
            shape=Point(v['x'],v['y']).buffer(v['diameter']/2,quad_segs=12),layers=[1,2],type='via',via=v))
    return out

def clearance(a,b):return .5 if a['net'] in HV or b['net'] in HV else .18

def fabrication_check(objs,routes,holes=HOLES,verbose=True):
    """Check drilling even on equal nets and the editor's 1 oz width limits."""
    drills=[]
    for o in objs:
        if o['type']=='pad' and o['pad']['hole']:
            p=o['pad'];drills.append((o['name'],Point(p['x'],p['y']),p['hole']))
        elif o['type']=='via':
            v=o['via'];drills.append((o['name'],Point(v['x'],v['y']),v['hole']))
    drills.extend(('mount'+str(i),Point(x,y),3.2) for i,(x,y) in enumerate(holes))
    errors=[]
    for i,(name,point,diameter) in enumerate(drills):
        for other,position,size in drills[:i]:
            gap=point.distance(position)-(diameter+size)/2
            if gap<.3-.00001:
                errors.append(dict(a=name,b=other,gap_mm=gap,required_mm=.3))
    widths=[dict(route=i,net=r['net'],width_mm=r['width'])
            for i,r in enumerate(routes) if not .127-.000001<=r['width']<=2.54+.000001]
    if verbose:
        print('DRILL_CLEARANCE',len(errors),errors)
        print('TRACK_WIDTH_LIMITS',len(widths),widths)
    return errors,widths


def component_pad_check(objs,verbose=True):
    """Check assembly spacing across components, including equal-net pads."""
    ps=[o for o in objs if o['type']=='pad']
    tree=STRtree([o['shape'] for o in ps]);errors=[]
    for i,a in enumerate(ps):
        for j in tree.query(a['shape'].buffer(.51)):
            if j>=i:continue
            b=ps[j]
            if a['pad']['ref']==b['pad']['ref'] or not set(a['layers'])&set(b['layers']):continue
            need=clearance(a,b);gap=a['shape'].distance(b['shape'])
            if gap<need-.003:
                errors.append(dict(a=a['name'],b=b['name'],a_net=a['net'],b_net=b['net'],
                    gap_mm=round(gap,6),overlap_mm2=round(a['shape'].intersection(b['shape']).area,6),
                    required_mm=need))
    if verbose:print('CROSS_COMPONENT_PAD_SPACING',len(errors),errors)
    return errors

def check(objs,verbose=True):
    tree=STRtree([o['shape'] for o in objs]);errors=[]
    for i,a in enumerate(objs):
        for j in tree.query(a['shape'].buffer(.51)):
            if j>=i:continue
            b=objs[j]
            if a['net']==b['net'] or not set(a['layers'])&set(b['layers']):continue
            # Library internal pad gaps are checked too, including NCs.
            need=clearance(a,b)
            d=a['shape'].distance(b['shape'])
            if d<need-.003:
                errors.append((a['name'],b['name'],round(d,4),need))
    if verbose:print('COPPER_CLEARANCE',len(errors),errors[:65])
    return errors

if __name__=='__main__':
    fixed=json.loads((BASE/'fixed-routes.json').read_text(encoding='utf-8'))
    check(items(fixed['routes'],fixed['vias']))
    body_check()
