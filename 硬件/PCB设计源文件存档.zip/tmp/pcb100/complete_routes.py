"""Finish the remaining supply routes using independent copper obstacles."""
import heapq, itertools
from geometry import *
from import_ses import connectivity
from shapely.ops import unary_union
import numpy as np
from shapely import contains_xy

D=json.loads((BASE/'routed.json').read_text())
STEP=.15;N=round(WIDTH/STEP)+1
xx,yy=np.meshgrid(np.arange(N)*STEP,np.arange(N)*STEP)

def connect(net,start,end,widths=(.25,.75)):
    objs=items(D['routes'],D['vias']);slots=footprint_slots()
    block=[];via_block=[]
    common=[Point(x,y).buffer(3.2) for x,y in HOLES]+[s['shape'].buffer(.305) for s in slots]
    for layer,width in zip([1,2],widths):
        other=[o['shape'].buffer((.505 if o['net'] in HV or net in HV else .185)+width/2,quad_segs=8)
               for o in objs if o['net']!=net and layer in o['layers']]
        forbidden=unary_union(other+common)
        b=contains_xy(forbidden,xx,yy)
        b|=(xx<.3+width/2)|(yy<.3+width/2)|(xx>WIDTH-.3-width/2)|(yy>HEIGHT-.3-width/2)
        block.append(b)
        vb=unary_union([o['shape'].buffer((.505 if o['net'] in HV or net in HV else .185)+.3,quad_segs=8)
               for o in objs if o['net']!=net and layer in o['layers']]+common)
        via_block.append(contains_xy(vb,xx,yy))
    via_ok=~(via_block[0]|via_block[1])
    def node(p):return (p[2]-1,round(p[0]/STEP),round(p[1]/STEP))
    a=node(start);z=node(end)
    # Each exact terminal joins the nearest legal grid point with checked copper.
    def bridge(p):
        li,x,y=node(p);candidates=[]
        for dx in range(-3,4):
            for dy in range(-3,4):
                u=x+dx;v=y+dy
                if not(0<=u<N and 0<=v<N) or block[li][v,u]:continue
                sh=LineString([(p[0],p[1]),(u*STEP,v*STEP)]).buffer(widths[li]/2,quad_segs=8)
                if any(o['net']!=net and li+1 in o['layers'] and sh.distance(o['shape'])<clearance(dict(net=net),o)-.002 for o in objs):continue
                if any(sh.distance(s['shape'])<.3 for s in slots):continue
                candidates.append(((u*STEP-p[0])**2+(v*STEP-p[1])**2,(li,u,v)))
        assert candidates,('No terminal escape',net,p)
        return min(candidates)[1]
    a=bridge(start);z=bridge(end)
    def heuristic(q):return ((q[1]-z[1])**2+(q[2]-z[2])**2)**.5*STEP
    costs={a:0};previous={};pq=[(heuristic(a),0,a)];expanded=0
    dirs=[(1,0),(0,1),(-1,0),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    while pq:
        _,cost,q=heapq.heappop(pq)
        if cost!=costs[q]:continue
        if q==z:break
        expanded+=1;li,x,y=q
        for dx,dy in dirs:
            u=x+dx;v=y+dy
            if not(0<=u<N and 0<=v<N) or block[li][v,u]:continue
            if dx and dy and (block[li][y,u] or block[li][v,x]):continue
            t=(li,u,v);c=cost+STEP*(1.41421356 if dx and dy else 1)*(1.3 if li==0 else 1)
            if c<costs.get(t,1e99):costs[t]=c;previous[t]=q;heapq.heappush(pq,(c+heuristic(t),c,t))
        if via_ok[y,x] and not block[1-li][y,x]:
            t=(1-li,x,y);c=cost+6
            if c<costs.get(t,1e99):costs[t]=c;previous[t]=q;heapq.heappush(pq,(c+heuristic(t),c,t))
    else:raise RuntimeError(('No path',net,start,end,expanded))
    path=[z]
    while path[-1]!=a:path.append(previous[path[-1]])
    path.reverse();li=path[0][0];pts=[[start[0],start[1]],[a[1]*STEP,a[2]*STEP]]
    def add_track(pts,li):
        # Collapse collinear lattice steps before serializing.
        clean=[]
        for xy in pts:
            if clean and xy==clean[-1]:continue
            if len(clean)>=2:
                v1=np.subtract(clean[-1],clean[-2]);v2=np.subtract(xy,clean[-1])
                if abs(v1[0]*v2[1]-v1[1]*v2[0])<1e-8 and np.dot(v1,v2)>=0:clean.pop()
            clean.append(xy)
        if len(clean)>1:D['routes'].append(dict(net=net,layer=li+1,width=widths[li],points=clean))
    for q,t in zip(path,path[1:]):
        xy=[round(t[1]*STEP,6),round(t[2]*STEP,6)]
        if q[0]!=t[0]:
            add_track(pts,li);D['vias'].append(dict(net=net,x=xy[0],y=xy[1],diameter=.6,hole=.3));li=t[0];pts=[xy]
        else:pts.append(xy)
    pts.append([end[0],end[1]]);add_track(pts,li)
    errors=check(items(D['routes'],D['vias']))
    assert not errors,errors
    assert not slot_check(items(D['routes'],D['vias']))
    print('CONNECTED',net,start,end,'expanded',expanded,flush=True)
    (BASE/'routed.json').write_text(json.dumps(D,indent=2),encoding='utf-8')

# Finish the independent input return before building the ground planes.
p=pin('J1',2);q=pin('C1',2)
connect('GND',(p['x'],p['y'],2),(q['x'],q['y'],2),(.6,1.2))
# Join USB supply islands through a 0.75 mm bottom distribution path.
points=[(pin('J15','B4A9'),1),(pin('J15','A4B9'),1),(pin('U2',16),1),(pin('C22',1),1),(pin('U12',5),1)]
for p,layer in points:
    connect('VBUS_USB',(p['x'],p['y'],layer),(47.2,77.9,2))
assert not connectivity(items(D['routes'],D['vias']))
print('ALL NETWORKS CONNECTED')
