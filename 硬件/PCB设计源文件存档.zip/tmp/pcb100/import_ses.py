"""Read router session paths, keep fixed copper and independently check nets."""
import re
from geometry import *

def sexpr(source):
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',source)
    root=[];stack=[root]
    for token in tokens:
        if token=='(':
            value=[];stack[-1].append(value);stack.append(value)
        elif token==')':stack.pop()
        else:
            stack[-1].append(json.loads(token) if token.startswith('"') else token)
    assert len(stack)==1
    return root[0]

def children(node,key):return [a for a in node if isinstance(a,list) and a and a[0]==key]
def child(node,key):return children(node,key)[0]

data=sexpr((BASE/'carrier.ses').read_text(encoding='utf-8'))
routes=[];vias=[]
for n in child(child(data,'routes'),'network_out')[1:]:
    assert n[0]=='net'
    net=n[1]
    for obj in n[2:]:
        if obj[0]=='wire':
            a=child(obj,'path');xy=[float(v)/1000 for v in a[3:]]
            routes.append(dict(net=net,layer=1 if a[1]=='F.Cu' else 2,width=float(a[2])/1000,
                               points=list(zip(xy[::2],xy[1::2]))))
        elif obj[0]=='via':
            vias.append(dict(net=net,x=float(obj[2])/1000,y=float(obj[3])/1000,
                             diameter=.55 if obj[1]=='V550_300' else .6,hole=.3))
fixed=json.loads((BASE/'fixed-routes.json').read_text(encoding='utf-8'))
def key(r):return (r['net'],r['layer'],round(r['width'],4),tuple((round(x,3),round(y,3)) for x,y in r['points']))
keys={key(r) for r in routes}
for r in fixed['routes']:
    if key(r) not in keys:routes.append(r)
vk={(v['net'],round(v['x'],3),round(v['y'],3)) for v in vias}
for v in fixed['vias']:
    if (v['net'],round(v['x'],3),round(v['y'],3)) not in vk:vias.append(v)
# Low-impedance return from the input terminal to the main ground reservoir.
a=pin('J1',2);b=pin('C1',2)
routes.append(dict(net='GND',layer=2,width=1.2,
                   points=[(a['x'],a['y']),(34.5,94),(b['x'],b['y'])]))

def connectivity(objs):
    parent=list(range(len(objs)))
    def find(i):
        while i!=parent[i]:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def join(i,j):parent[find(i)]=find(j)
    tree=STRtree([o['shape'] for o in objs])
    for i,a in enumerate(objs):
        for j in tree.query(a['shape'].buffer(.003)):
            if j>=i:continue
            b=objs[j]
            if a['net']!=b['net'] or not set(a['layers'])&set(b['layers']):continue
            if a['shape'].distance(b['shape'])<=.002:join(i,j)
    groups={}
    for i,a in enumerate(objs):
        if a['type']=='pad' and not a['net'].startswith('NC_'):
            groups.setdefault(a['net'],{}).setdefault(find(i),[]).append(a['name'])
    missing={n:list(g.values()) for n,g in groups.items() if len(g)>1}
    # Supply geometry for manual final corrections.
    return missing

def report(routes,vias):
    objs=items(routes,vias)
    errors=check(objs)
    missing=connectivity(objs)
    print('UNCONNECTED_NETS',len(missing),json.dumps(missing))
    return dict(clearance_errors=errors,unconnected=missing,routes=len(routes),vias=len(vias))

if __name__=='__main__':
    # Do not replace manually repaired routes with a stale router session.
    for component in children(child(data,'placement'),'component'):
        for p in children(component,'place'):
            if p[1] in PLACE:
                actual=(float(p[2])/1000,float(p[3])/1000,float(p[5]))
                assert max(abs(a-b) for a,b in zip(actual,PLACE[p[1]]))<.001,(
                    'Stale router session placement; use corrected routed.json or reroute',p[1],actual,PLACE[p[1]])
    (BASE/'routed.json').write_text(json.dumps({'routes':routes,'vias':vias},indent=2),encoding='utf-8')
    result=report(routes,vias)
    (BASE/'routing-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
