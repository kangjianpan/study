PCB design source snapshot, updated 2026-11-17.

Extract at the project root, preserving the tmp/ paths. The active delivery is
hardware folder's Chinese-named .epro2 file, referenced in the root README.md.
Scripts now target that folder. Python 3, Shapely 2.x and Pillow are required;
they are external dependencies and are not bundled. For example:
  python -m pip install --target tmp/pcb-v2/python-libs shapely
  python -m pip install Pillow

Current corrected inputs:
  board.py: placement, including C5 (41.2,81) and C50 (58.6,91).
  routed.json / final-design.json: repaired capacitor and ESP_RX copper.
  repaired-project.json: schematic source including existing assembly notes.
  fixed-routes.json / carrier.dsn: regenerated for the new placement.

Normal maintenance:
  python tmp/pcb-v2/verify_archive.py
  python tmp/pcb-v2/render_board.py
  finish_board.py can regenerate the project from corrected routed.json.
  annotate_project.py is idempotent; existing assembly notes are retained.

Historical data:
  carrier.ses is the original Freerouting 2.5.0 session, before the local repair.
  Do not import it over current routed.json. import_ses.py refuses its stale
  placement. A new routing run must start from updated carrier.dsn.
  pad-spacing-before-design.json stores old copper for the overlap regression.
  repair_pad_spacing.py was used on the pre-fix archive (Git e863ba6); it checks
  expected original locations and intentionally refuses to patch twice.

Checks cover different-net copper, cross-component pads including equal nets,
connectivity, bodies, text envelopes, board edges and mounting holes.
The archived official parser scripts require the local EasyEDA client 3.2.91.
They validate parsing only. Online editor ERC/DRC, footprint selection and
physical assembly still require review before fabrication.
