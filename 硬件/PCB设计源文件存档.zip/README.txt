PCB design source snapshot, updated 2026-11-17.

Extract at the project root, preserving the tmp/ paths. The active delivery is
hardware folder's Chinese-named .epro2 file, referenced in the root README.md.
Scripts now target that folder. Python 3, Shapely 2.x and Pillow are required;
they are external dependencies and are not bundled. For example:
  python -m pip install --target tmp/pcb-v2/python-libs shapely
  python -m pip install Pillow

Current corrected inputs:
  board.py: placement, including C5 (41.2,81) and C50 (58.6,91).
  routed.json / final-design.json: capacitor, ESP_RX and USB-C cutout repairs.
  repaired-project.json: editor-synchronized schematic and component template.
  ground-plane.wkt / ground-plane-top.wkt: bottom and top GND copper.
  fixed-routes.json / carrier.dsn: historical autorouter input, before USB repair.

Normal maintenance:
  python tmp/pcb-v2/verify_archive.py
  python tmp/pcb-v2/render_board.py
  finish_board.py is the historical bottom-plane starting-layout generator;
  it does not reproduce the later editor-added top plane. Do not overwrite
  the current delivery with that intermediate output.
  annotate_project.py is idempotent; existing assembly notes are retained.
  repair_usb_slots.py reproduces the current two-plane repair on the user's
  pre-repair archive at Git b3fb7ad. It verifies copper before replacing it.
  usb-slot-before-design.json is the corresponding regression input.

Historical data:
  carrier.ses is the original Freerouting 2.5.0 session, before the local repair.
  Do not import it over current routed.json. import_ses.py refuses its stale
  placement. A new routing run must start from updated carrier.dsn.
  pad-spacing-before-design.json stores old copper for the overlap regression.
  repair_pad_spacing.py is historical. Use the older source snapshot at Git
  28b2f29 to reproduce that repair; current library UUIDs differ after Save As.

Checks cover different-net copper, cross-component pads including equal nets,
connectivity, bodies, text envelopes, board edges, mounting holes and footprint
through-cutouts (including the two 0.6 mm USB-C alignment holes).
The archived official parser scripts require the local EasyEDA client 3.2.91.
They validate parsing only. Online editor ERC/DRC, footprint selection and
physical assembly still require review before fabrication.
