PCB design source snapshot, before folder cleanup.
Contains millimetre placement, fixed routes, router session, copper finishing,
independent archive checks, repaired library source, and schematic note patch.
Archive paths preserve the original temporary layout. After extraction, update
project paths to hardware folder (original Chinese folder name is shown in root README).
Python 3, Shapely 2.x and Pillow are external requirements, not bundled.
Routing used Freerouting 2.5.0. Official parser scripts require local EasyEDA client.
finish_board.py regenerates the pre-note project; apply annotate_project.py afterward.
