PCB design source snapshot, updated 2026-11-17: 100 x 100 mm carrier.

Extract at the project root, preserving tmp/ paths. Only the Chinese-named
.epro2 in the hardware folder is the active user delivery. The original
130 x 100 mm delivery and source snapshot remain in Git commit bb92d64.

Dependencies: Python 3, Shapely 2.x, Pillow. Example installation:
  python -m pip install --target tmp/pcb-v2/python-libs shapely
  python -m pip install Pillow
The pcb-v2/python-libs location is the dependency path used by geometry.py.
Freerouting 2.5.0 with Java 25 was used for initial routing. Router binaries,
JRE and Python packages are external dependencies and are not bundled.

Current sources:
  tmp/pcb100/board.py: final 139-component placement, 100 mm outline.
  tmp/pcb100/routed.json: final corrected and connected copper.
  tmp/pcb100/final-design.json: widths normalized by final generation.
  tmp/import-repair/repaired-project.json: synchronized electrical template.
  tmp/import-repair/repaired-parts.json: original component/net definitions.

Regenerate candidate without changing the active delivery:
  python tmp/pcb100/finish_board.py
  python tmp/pcb100/verify_archive.py
  python tmp/pcb100/render_board.py
finish_board.py produces a candidate .epro2 in tmp/pcb100/. Its image resources
are copied from the active hardware archive. Inspect and verify the candidate
before copying it to the hardware folder. Verify electrical equivalence
against an original archive extracted from Git bb92d64:
  python tmp/pcb100/verify_equivalence.py BASELINE.epro2 CANDIDATE.epro2

The saved carrier.ses is the historical initial router result. It precedes
local obstacle-aware completion, duplicate removal and power-width changes.
Do not run import_ses.py or complete_routes.py over final routed.json.
export_dsn.py rebuilds the historical router input and fixed-routes.json;
it is not needed for final regeneration from saved routed.json.

Official file-parser validation uses the locally installed EasyEDA Pro
3.2.91 client at the path embedded in verify_official.cjs:
  node tmp/import-repair/verify_official.cjs tmp/pcb100/final.epru CANDIDATE.epro2
Its report goes to tmp/import-repair/official-check.json. The explicit
archive argument binds the report hash to the candidate, not an older file.

Independent checks cover net continuity, different-net copper clearance,
cross-component pads including equal-net pads, component body overlap,
core-board occupancy, text envelopes, board edges, mounting holes and the
two USB-C mechanical through-cutouts. These checks and official parsing
are not online editor ERC/DRC. Import, rebuild all pours and run official
ERC/DRC in the editor before fabrication, then check physical fit.
